--
-- PostgreSQL database dump
--

\restrict B8MZZiox2VrCAZy4vgh3tj552mPSWPzXKFHA0bepidroDwPaFAxughEdLZJeEyB

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: christian
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO christian;

--
-- Name: books; Type: TABLE; Schema: public; Owner: christian
--

CREATE TABLE public.books (
    id text NOT NULL,
    title text NOT NULL,
    publisher text,
    year text,
    description text,
    "coverUrl" text,
    "coverKey" text,
    "order" integer DEFAULT 0 NOT NULL,
    "profileId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.books OWNER TO christian;

--
-- Name: featured_works; Type: TABLE; Schema: public; Owner: christian
--

CREATE TABLE public.featured_works (
    id text NOT NULL,
    url text NOT NULL,
    key text NOT NULL,
    "order" integer DEFAULT 0 NOT NULL,
    "homepageId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "seriesId" text
);


ALTER TABLE public.featured_works OWNER TO christian;

--
-- Name: homepages; Type: TABLE; Schema: public; Owner: christian
--

CREATE TABLE public.homepages (
    id text NOT NULL,
    "heroImageUrl" text,
    "heroImageKey" text,
    "heroText" text DEFAULT ''::text NOT NULL,
    presentation text DEFAULT ''::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "manifestoTitle" text DEFAULT 'La Démarche'::text NOT NULL,
    "heroSubtitle" text DEFAULT ''::text NOT NULL
);


ALTER TABLE public.homepages OWNER TO christian;

--
-- Name: photos; Type: TABLE; Schema: public; Owner: christian
--

CREATE TABLE public.photos (
    id text NOT NULL,
    url text NOT NULL,
    key text NOT NULL,
    "order" integer DEFAULT 0 NOT NULL,
    "seriesId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    caption text,
    year text,
    variants jsonb
);


ALTER TABLE public.photos OWNER TO christian;

--
-- Name: profiles; Type: TABLE; Schema: public; Owner: christian
--

CREATE TABLE public.profiles (
    id text NOT NULL,
    name text DEFAULT 'Christian Ramade'::text NOT NULL,
    bio text DEFAULT ''::text NOT NULL,
    "avatarUrl" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    tagline text DEFAULT 'Observing the Unseen.'::text NOT NULL
);


ALTER TABLE public.profiles OWNER TO christian;

--
-- Name: series; Type: TABLE; Schema: public; Owner: christian
--

CREATE TABLE public.series (
    id text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    "coverUrl" text,
    "order" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    description text,
    "shootDate" timestamp(3) without time zone,
    tags text[] DEFAULT ARRAY[]::text[],
    visibility text DEFAULT 'private'::text NOT NULL,
    "shootDateLabel" text,
    "referenceUrl" text,
    "linkedTicketId" text,
    featured boolean DEFAULT false NOT NULL
);


ALTER TABLE public.series OWNER TO christian;

--
-- Name: subscribers; Type: TABLE; Schema: public; Owner: christian
--

CREATE TABLE public.subscribers (
    id text NOT NULL,
    email text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.subscribers OWNER TO christian;

--
-- Name: tickets; Type: TABLE; Schema: public; Owner: christian
--

CREATE TABLE public.tickets (
    id text NOT NULL,
    title text NOT NULL,
    slug text NOT NULL,
    content text DEFAULT ''::text NOT NULL,
    excerpt text,
    "coverUrl" text,
    "coverKey" text,
    status text DEFAULT 'draft'::text NOT NULL,
    tags text[] DEFAULT ARRAY[]::text[],
    "order" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.tickets OWNER TO christian;

--
-- Name: timeline_items; Type: TABLE; Schema: public; Owner: christian
--

CREATE TABLE public.timeline_items (
    id text NOT NULL,
    title text NOT NULL,
    year text NOT NULL,
    description text,
    "order" integer DEFAULT 0 NOT NULL,
    "profileId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    location text
);


ALTER TABLE public.timeline_items OWNER TO christian;

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: christian
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
a788013b-e318-49b2-93bb-6c22690386ff	09a3d569b1a5e1d235a4c80d0798cac8425bcbd1cd9e338d86938fe2cf3334c0	2026-08-23 10:34:05.358214+00	20260717084249_init	\N	\N	2026-08-23 10:34:05.332236+00	1
dc119840-3dcc-455b-9608-cec10f552cca	89c469dee0c49b3e158efb62268e702e2adec4715ee463b0f768ef95137fef4a	2026-08-24 10:59:10.844675+00	20260824000000_add_manifesto_title	\N	\N	2026-08-24 10:59:10.823851+00	1
94261441-502d-4c30-9679-afd8c6989f84	b49e91db7abe4795f132468b8563f91f35b33e6dff1bc311a879c248ead888d1	2026-08-23 10:34:05.363738+00	20260717091634_add_series_fields	\N	\N	2026-08-23 10:34:05.358933+00	1
ae938b07-52c9-497a-b0f3-eb3757039344	5f5401419b3eb8def01595c57659ea255331ea7ad32a0380108d4772653533ec	2026-08-23 10:34:05.374425+00	20260717115905_add_tickets	\N	\N	2026-08-23 10:34:05.364543+00	1
3a02a37d-acdd-44c9-bee5-5f79db6294ff	28e2117b8072866cf9dbe61c5a7a263dd61c9c60becce93faef4f8bd5c6e712c	2026-08-23 10:34:05.394649+00	20260717121627_add_profile	\N	\N	2026-08-23 10:34:05.375567+00	1
c7f0c484-2adc-4501-bacb-8bc5366006df	a00472aa7a0ede0f712f96dbad276f931d6a7ddc3b8b3b6d72222db6ed39d667	2026-09-13 17:31:35.676424+00	20260913000000_add_photo_caption_year	\N	\N	2026-09-13 17:31:35.631025+00	1
51916c9d-4c5b-4760-af09-4494c0552afa	7de404cc4df59500e6d1f5da613e96a119d0be9395d0a3990cc669d3c7444fc4	2026-08-23 10:34:05.399484+00	20260717131539_add_tagline	\N	\N	2026-08-23 10:34:05.395802+00	1
fa5bbf7b-55ed-4692-b696-364710304adc	327fab5b0ce21a5f410dae832deac081f9356c8c4ddbd279b3d1086ebd998531	2026-08-23 10:34:05.403165+00	20260717131731_add_location	\N	\N	2026-08-23 10:34:05.400186+00	1
3431d1d0-1b36-4818-b56e-9b2750f9a6a6	ec5cf437e88da2ea86eca5ac8360c7bc3f42e12308b3a0769742a4d3dc4855e6	2026-08-23 10:34:05.410988+00	20260725093933_add_shoot_date_label	\N	\N	2026-08-23 10:34:05.404925+00	1
6c57067e-765c-4e4d-8032-52075ce4d69f	ebc7d0776bf6cb60750d51f73e04ae5c6e1d22b9602e2d8c962e230111a00230	2026-09-13 17:31:35.709189+00	20260913010000_add_hero_subtitle	\N	\N	2026-09-13 17:31:35.678688+00	1
ff5415e6-baed-4c14-bf9f-da14272737af	b13954364d32ce9e7db18a027867ce012f1234a8e4d7712c7a5c6bd453fb2438	2026-08-23 10:34:05.416589+00	20260725095003_add_reference_url	\N	\N	2026-08-23 10:34:05.411865+00	1
c729ba7f-1783-418a-8c64-5331b42a75d6	a05020ec481c838e139003ff9bf3a5203146a76bd85a5c1fc9b5e682075ad5f0	2026-08-23 10:34:05.423826+00	20260725095441_add_linked_ticket	\N	\N	2026-08-23 10:34:05.417315+00	1
97ead8bc-f57e-4405-b387-ac944434642b	b848ed9fd55ca75b0f5c6fb11aafdb18bce02f68a26c14088760aee593809835	2026-08-23 10:34:05.430196+00	20260725101256_add_featured	\N	\N	2026-08-23 10:34:05.424743+00	1
60a564b0-d73a-447c-9b7b-4ceeade7452d	0672fa89e8ffcff3cce9c648a7ea473a60a81666888881d3e83e9b152dbd208a	2026-08-23 10:34:05.440005+00	20260725103349_add_subscribers	\N	\N	2026-08-23 10:34:05.431222+00	1
ba89f2c5-ae38-401b-8e89-1a40694f505b	b87e945a242d49967928460c550f889cf227faa2859ece867268ec4003db50a6	2026-08-23 10:34:05.454931+00	20260820090000_add_homepage	\N	\N	2026-08-23 10:34:05.440695+00	1
5f344e4b-6d43-445d-a6f6-a8d970aa5f3a	0b3e8996f5b5236ea80bd9da989843cc44e05bd980f1eb15ffda435c60b8ed7e	2026-08-23 10:34:05.461533+00	20260820100000_add_featured_work_series	\N	\N	2026-08-23 10:34:05.455968+00	1
\.


--
-- Data for Name: books; Type: TABLE DATA; Schema: public; Owner: christian
--

COPY public.books (id, title, publisher, year, description, "coverUrl", "coverKey", "order", "profileId", "createdAt", "updatedAt") FROM stdin;
cmtfsnd29005c22llu3fieavu	Marseille chemins d'intimité	\N	\N	\N	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788093409316-Marseille-Chemins-d-intimit-.jpg	uploads/1788093409316-Marseille-Chemins-d-intimit-.jpg	1	cmt5oow53000022nzmt2pssta	2026-08-30 12:36:49.761	2026-08-30 12:56:24.928
cmtft1hei005g22llsre5ayk9	Marseille Vraiment	\N	\N	\N	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788094068020-Marseille-vraiment-08568.jpg	uploads/1788094068020-Marseille-vraiment-08568.jpg	0	cmt5oow53000022nzmt2pssta	2026-08-30 12:47:48.57	2026-08-30 12:56:24.927
cmtfscphg005022llaqrvbgh4	Aucunes bête aussi féroce	\N	\N	\N	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788092911974-Aucube-b-tes.jpg	uploads/1788092911974-Aucube-b-tes.jpg	2	cmt5oow53000022nzmt2pssta	2026-08-30 12:28:32.644	2026-08-30 12:56:24.929
cmtfsgta0005522llj4rlhbt9	La part du ciel	\N	\N	\N	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788093103762-Germaine-cata-ENP-08574.jpg	uploads/1788093103762-Germaine-cata-ENP-08574.jpg	6	cmt5oow53000022nzmt2pssta	2026-08-30 12:31:44.184	2026-08-30 12:56:24.931
cmtfseo6a005222llgzuq24oh	Escale à Thessalonique	\N	\N	\N	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788093003273-Escale---Thessalonique.jpg	uploads/1788093003273-Escale---Thessalonique.jpg	3	cmt5oow53000022nzmt2pssta	2026-08-30 12:30:04.258	2026-08-30 12:56:24.93
cmtfsi5e3005722ll8i34h956	Marcel pagnol à aubagne	\N	\N	\N	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788093166045-Germaine-cata-ENP-08578.jpg	uploads/1788093166045-Germaine-cata-ENP-08578.jpg	8	cmt5oow53000022nzmt2pssta	2026-08-30 12:32:46.539	2026-08-30 12:56:24.933
cmtfsj08r005822llxxqokvfj	Virginia Woolf à Cassis	\N	\N	\N	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788093206139-Germaine-cata-ENP-08579.jpg	uploads/1788093206139-Germaine-cata-ENP-08579.jpg	9	cmt5oow53000022nzmt2pssta	2026-08-30 12:33:26.523	2026-08-30 12:56:24.933
cmtft65ae005h22lljbd3l9v3	Albert Cohen à Marseille	\N	\N	\N	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788094285698-Germaine-cata-ENP-08577.jpg	uploads/1788094285698-Germaine-cata-ENP-08577.jpg	7	cmt5oow53000022nzmt2pssta	2026-08-30 12:51:26.15	2026-08-30 12:56:24.932
cmtft8g35005i22lltakk2x12	Ceci n'est pas une carte postale	\N	\N	\N	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788094393038-Germaine-cata-ENP-08583.jpg	uploads/1788094393038-Germaine-cata-ENP-08583.jpg	10	cmt5oow53000022nzmt2pssta	2026-08-30 12:53:13.457	2026-08-30 12:56:24.936
cmtfsk6vn005922llx0dc6tme	Germainr et le Nord Pinus	\N	\N	\N	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788093261246-Germaine-cata-ENP-08588.jpg	uploads/1788093261246-Germaine-cata-ENP-08588.jpg	13	cmt5oow53000022nzmt2pssta	2026-08-30 12:34:21.779	2026-08-30 12:56:24.937
cmtfsotqm005e22llh6qxhexs	Zoom italien N°125	\N	\N	\N	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788093477569-Zoom-italien-N-125.jpg	uploads/1788093477569-Zoom-italien-N-125.jpg	15	cmt5oow53000022nzmt2pssta	2026-08-30 12:37:58.03	2026-08-30 12:56:24.937
cmtfsg179005422llhe4xv79w	Le château Borély	\N	\N	\N	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788093067355-Germaine-cata-ENP-08573.jpg	uploads/1788093067355-Germaine-cata-ENP-08573.jpg	5	cmt5oow53000022nzmt2pssta	2026-08-30 12:31:07.797	2026-08-30 12:56:24.931
cmtfsmns9005b22llp13h9n30	Les trésors cachés du Sacro Monte di Orta	\N	\N	\N	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788093376339-Le-Sacro-Monte-d-Orta.jpg	uploads/1788093376339-Le-Sacro-Monte-d-Orta.jpg	16	cmt5oow53000022nzmt2pssta	2026-08-30 12:36:17.001	2026-08-30 12:56:24.937
cmtfslbxx005a22ll4g0pyqrw	Germaine et lr Nord-Pinus	\N	\N	\N	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788093314201-Germaine-et-le-Nord-Pinus.jpg	uploads/1788093314201-Germaine-et-le-Nord-Pinus.jpg	14	cmt5oow53000022nzmt2pssta	2026-08-30 12:35:14.997	2026-08-30 12:56:24.937
cmtfsqokd005f22ll3atrgte2	Photo-Roman	\N	\N	\N	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788093564120-Photo-Roman.jpg	uploads/1788093564120-Photo-Roman.jpg	11	cmt5oow53000022nzmt2pssta	2026-08-30 12:39:24.637	2026-08-30 12:56:24.936
cmtfso5u1005d22lle81x9cpj	Poteaugraphies	\N	\N	\N	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788093446367-Poteaugraphies.jpg	uploads/1788093446367-Poteaugraphies.jpg	12	cmt5oow53000022nzmt2pssta	2026-08-30 12:37:27.049	2026-08-30 12:56:24.936
cmtfsf7nk005322llj6txpbpf	L'oeil étonné	\N	\N	\N	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788093028977-Germaine-cata-ENP-08572.jpg	uploads/1788093028977-Germaine-cata-ENP-08572.jpg	4	cmt5oow53000022nzmt2pssta	2026-08-30 12:30:29.504	2026-08-30 12:56:24.93
\.


--
-- Data for Name: featured_works; Type: TABLE DATA; Schema: public; Owner: christian
--

COPY public.featured_works (id, url, key, "order", "homepageId", "createdAt", "updatedAt", "seriesId") FROM stdin;
cmt5wpn79001m22pmrqy5f1uz	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787492564049-002-Germaine--jpg.jpg		1	cmt5wf8ev001k22pmp61busue	2026-08-23 14:32:52.917	2026-08-23 14:32:52.917	cmt5ux60t000f22pmb6l0ko8q
cmt7ho9ll000022ll02cg26e8	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787492213133-Marseille-Prado.jpg		2	cmt5wf8ev001k22pmp61busue	2026-08-24 17:07:26.745	2026-08-24 17:07:26.745	cmt5u9wg3000222pms8nvr7ig
cmt8ol2t1002k22ll35p3073g	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787645161969-Le-voyage-m-diterran-en-1-2.jpg		3	cmt5wf8ev001k22pmp61busue	2026-08-25 13:08:41.462	2026-08-25 13:08:41.462	cmt8drvac001222llau5y0lwi
\.


--
-- Data for Name: homepages; Type: TABLE DATA; Schema: public; Owner: christian
--

COPY public.homepages (id, "heroImageUrl", "heroImageKey", "heroText", presentation, "createdAt", "updatedAt", "manifestoTitle", "heroSubtitle") FROM stdin;
cmt5wf8ev001k22pmp61busue	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788009423989-Marseille-Prado.jpg	uploads/1788009423989-Marseille-Prado.jpg	Voyage dans mes images...	Je suis souvent parti seul faire des photographies sans savoir ce que je cherchais car c’est pour moi le meilleur moyen de rencontrer quelque chose d’inattendu...	2026-08-23 14:24:47.191	2026-08-30 13:04:59.698	La Démarche	
\.


--
-- Data for Name: photos; Type: TABLE DATA; Schema: public; Owner: christian
--

COPY public.photos (id, url, key, "order", "seriesId", "createdAt", "updatedAt", caption, year, variants) FROM stdin;
cmt5ud1v3000c22pmtubtklg1	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787491625157-poteau-vallon-des-tuves-.jpg	uploads/1787491625157-poteau-vallon-des-tuves-.jpg	8	cmt5u9wg3000222pms8nvr7ig	2026-08-23 13:27:06.159	2026-08-23 13:29:54.172	\N	\N	\N
cmt5ud1sj000522pmzu9y1p3r	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787491625151-La-Corniche-Marseille.jpg	uploads/1787491625151-La-Corniche-Marseille.jpg	4	cmt5u9wg3000222pms8nvr7ig	2026-08-23 13:27:06.067	2026-08-23 13:29:54.168	\N	\N	\N
cmt5ud1rq000422pmbdvdaryx	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787491625153-Marseille--les-iles.jpg	uploads/1787491625153-Marseille--les-iles.jpg	9	cmt5u9wg3000222pms8nvr7ig	2026-08-23 13:27:06.038	2026-08-23 13:29:54.173	\N	\N	\N
cmt5ud1te000622pm2m3lnf8u	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787491625150-Le-Moll-San-Remo-site-3.jpg	uploads/1787491625150-Le-Moll-San-Remo-site-3.jpg	5	cmt5u9wg3000222pms8nvr7ig	2026-08-23 13:27:06.098	2026-08-23 13:29:54.17	\N	\N	\N
cmt5ud1ww000d22pmtxql3as9	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787491625160-Le-Maregraphe-1.jpg	uploads/1787491625160-Le-Maregraphe-1.jpg	3	cmt5u9wg3000222pms8nvr7ig	2026-08-23 13:27:06.225	2026-08-23 13:29:54.167	\N	\N	\N
cmt5ud1u5000a22pmq9qmhl9y	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787491625153-Vermeer.-Le-photographe-de-f-s-.jpg	uploads/1787491625153-Vermeer.-Le-photographe-de-f-s-.jpg	0	cmt5u9wg3000222pms8nvr7ig	2026-08-23 13:27:06.125	2026-08-23 13:29:54.164	\N	\N	\N
cmt5ud1u3000922pmubd1hdf8	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787491625156-Lac-de-C-me.-Villa.jpg	uploads/1787491625156-Lac-de-C-me.-Villa.jpg	6	cmt5u9wg3000222pms8nvr7ig	2026-08-23 13:27:06.123	2026-08-23 13:29:54.171	\N	\N	\N
cmt5ud1ty000822pmdgzosms1	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787491625154-nu-barcelonne-01-.jpg	uploads/1787491625154-nu-barcelonne-01-.jpg	7	cmt5u9wg3000222pms8nvr7ig	2026-08-23 13:27:06.118	2026-08-23 13:29:54.172	\N	\N	\N
cmt5ud1ts000722pm7anp3u31	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787491625152-La-cote-bleue.jpg	uploads/1787491625152-La-cote-bleue.jpg	2	cmt5u9wg3000222pms8nvr7ig	2026-08-23 13:27:06.112	2026-08-23 13:29:54.167	\N	\N	\N
cmt5ud1up000b22pmo0iafcix	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787491625152-La-crau-2.jpg	uploads/1787491625152-La-crau-2.jpg	1	cmt5u9wg3000222pms8nvr7ig	2026-08-23 13:27:06.145	2026-08-23 13:29:54.166	\N	\N	\N
cmt5ud1qt000322pmbvym7le4	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787491625157-Train-de-la-mure-.jpg	uploads/1787491625157-Train-de-la-mure-.jpg	10	cmt5u9wg3000222pms8nvr7ig	2026-08-23 13:27:06.005	2026-08-23 13:29:54.174	\N	\N	\N
cmt5ud1y7000e22pm0ow2foii	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787491625154-Marseille-Prado.jpg	uploads/1787491625154-Marseille-Prado.jpg	11	cmt5u9wg3000222pms8nvr7ig	2026-08-23 13:27:06.271	2026-08-23 13:29:54.174	\N	\N	\N
cmt5uzrm6000n22pmdpqyfcj4	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787492683524-014-Germaine-buanderie-.jpg	uploads/1787492683524-014-Germaine-buanderie-.jpg	10	cmt5ux60t000f22pmb6l0ko8q	2026-08-23 13:44:45.966	2026-08-23 13:47:20.188	\N	\N	\N
cmt5uzrne000o22pm6umvlkoj	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787492683527-006-Germaine-petit-salon-.jpg	uploads/1787492683527-006-Germaine-petit-salon-.jpg	3	cmt5ux60t000f22pmb6l0ko8q	2026-08-23 13:44:46.01	2026-08-23 13:47:20.183	\N	\N	\N
cmt5uzrk3000k22pmw94v17hd	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787492683526-007-Germaine-camargue-.jpg	uploads/1787492683526-007-Germaine-camargue-.jpg	11	cmt5ux60t000f22pmb6l0ko8q	2026-08-23 13:44:45.891	2026-08-23 13:47:20.189	\N	\N	\N
cmt5uzroe000q22pm5zsgiwg9	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787492683522-012-Germaine-chambre-.jpg	uploads/1787492683522-012-Germaine-chambre-.jpg	12	cmt5ux60t000f22pmb6l0ko8q	2026-08-23 13:44:46.046	2026-08-23 13:47:20.189	\N	\N	\N
cmt5uzrjx000j22pm7gg1ecvz	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787492683529-004.jpg	uploads/1787492683529-004.jpg	2	cmt5ux60t000f22pmb6l0ko8q	2026-08-23 13:44:45.885	2026-08-23 13:47:20.183	\N	\N	\N
cmt5uzre9000g22pmdijx8t2n	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787492683526-010-Germaine-chambre-avec-bain-.jpg	uploads/1787492683526-010-Germaine-chambre-avec-bain-.jpg	6	cmt5ux60t000f22pmb6l0ko8q	2026-08-23 13:44:45.681	2026-08-23 13:47:20.186	\N	\N	\N
cmt5uzrkt000l22pmnwlrdb9b	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787492683525-013-Germaine-chambre-automate-.jpg	uploads/1787492683525-013-Germaine-chambre-automate-.jpg	7	cmt5ux60t000f22pmb6l0ko8q	2026-08-23 13:44:45.917	2026-08-23 13:47:20.186	\N	\N	\N
cmtlby0n2008322llw2giorbx	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788428150090-Z-bre.jpg	uploads/1788428150090-Z-bre.jpg	14	cmtefwkh3004h22llaqss7tuf	2026-09-03 09:35:50.462	2026-09-03 09:41:27.798	\N	\N	\N
cmtsp4c48008a22lligj69xux	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788873543069-Malmousque-ter.jxl	uploads/1788873543069-Malmousque-ter.jxl	17	cmthvob3v005j22llw2pmotim	2026-09-08 13:19:03.512	2026-09-09 20:05:58.234	\N	\N	\N
cmt8ds7pr001o22lloakvfbsm	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787645176699-Le-voyage-m-diterran-en--3.jpg	uploads/1787645176699-Le-voyage-m-diterran-en--3.jpg	13	cmt8drvac001222llau5y0lwi	2026-08-25 08:06:18.639	2026-08-25 20:24:05.719	\N	\N	\N
cmt8lx472002222lld7uz0v2g	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787658840201-Poteauygraphies-36.jpg	uploads/1787658840201-Poteauygraphies-36.jpg	0	cmt8lu9lb001r22ll1tl78jtv	2026-08-25 11:54:04.286	2026-08-27 08:47:19.643	\N	\N	\N
cmt8lx4he002g22llp29rywyy	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787658840203-Poteauygraphies-47.jpg	uploads/1787658840203-Poteauygraphies-47.jpg	21	cmt8lu9lb001r22ll1tl78jtv	2026-08-25 11:54:04.658	2026-08-27 08:47:19.659	\N	\N	\N
cmt8ds7lj001m22llrch96wtk	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787645176700-Le-voyage-m-diterran-en--5.jpg	uploads/1787645176700-Le-voyage-m-diterran-en--5.jpg	14	cmt8drvac001222llau5y0lwi	2026-08-25 08:06:18.487	2026-08-25 20:24:05.719	\N	\N	\N
cmt7i2kyk000422lle47o6jxj	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787591913410-St.-italie-selection-2000-dpi-jpg-26.jpg	uploads/1787591913410-St.-italie-selection-2000-dpi-jpg-26.jpg	6	cmt7i1iaq000322lly1wd99fe	2026-08-24 17:18:34.653	2026-08-24 17:27:35.643	\N	\N	\N
cmtuozbvo008x22ll6kz12ja5	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788994241794-Sainte-victoire.jxl	uploads/1788994241794-Sainte-victoire.jxl	15	cmt8v8qgb002l22llf0q3b3tx	2026-09-09 22:50:42.276	2026-09-09 22:51:41.732	\N	\N	\N
cmt7i2l3t000f22ll1hwqcasc	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787591913385-faux-semblant-04-2000.jpg	uploads/1787591913385-faux-semblant-04-2000.jpg	19	cmt7i1iaq000322lly1wd99fe	2026-08-24 17:18:34.841	2026-08-24 17:27:35.647	\N	\N	\N
cmt7i2l39000d22llcp6x1w1s	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787591913403-Orta-village.jpg	uploads/1787591913403-Orta-village.jpg	26	cmt7i1iaq000322lly1wd99fe	2026-08-24 17:18:34.821	2026-08-24 17:27:35.649	\N	\N	\N
cmt8ds7hw001k22llldrxo1jv	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787645176707-Le-voyage-m-diterran-en--12.jpg	uploads/1787645176707-Le-voyage-m-diterran-en--12.jpg	10	cmt8drvac001222llau5y0lwi	2026-08-25 08:06:18.356	2026-08-25 20:24:05.718	\N	\N	\N
cmt5uzri0000h22pme9u0om82	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787492683525-011-Germaine-chambre-draps-.jpg	uploads/1787492683525-011-Germaine-chambre-draps-.jpg	8	cmt5ux60t000f22pmb6l0ko8q	2026-08-23 13:44:45.816	2026-08-23 13:47:20.187	\N	\N	\N
cmt7i2l1e000622ll3wfyx3rk	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787591913346-021-Pa.-venise-italie-selection-2000-dpi-jpg-12.jpg	uploads/1787591913346-021-Pa.-venise-italie-selection-2000-dpi-jpg-12.jpg	15	cmt7i1iaq000322lly1wd99fe	2026-08-24 17:18:34.754	2026-08-24 17:27:35.646	\N	\N	\N
cmt7i2l7a000k22llty0wwodv	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787591913399-Marion-porche-Italie-2024.jpg	uploads/1787591913399-Marion-porche-Italie-2024.jpg	23	cmt7i1iaq000322lly1wd99fe	2026-08-24 17:18:34.966	2026-08-24 17:27:35.649	\N	\N	\N
cmt7i2l4g000g22llv6mhs27b	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787591913371-Alassio-.jpg	uploads/1787591913371-Alassio-.jpg	22	cmt7i1iaq000322lly1wd99fe	2026-08-24 17:18:34.864	2026-08-24 17:27:35.649	\N	\N	\N
cmt7i2l7z000n22llf8vz6fv3	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787591913399-Mus.-italie-selection-2000-dpi-jpg-105.jpg	uploads/1787591913399-Mus.-italie-selection-2000-dpi-jpg-105.jpg	25	cmt7i1iaq000322lly1wd99fe	2026-08-24 17:18:34.991	2026-08-24 17:27:35.649	\N	\N	\N
cmtlc4squ008422llpxfkpe8o	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788428466534-Atelier-taxiderlie.jpg	uploads/1788428466534-Atelier-taxiderlie.jpg	18	cmtefwkh3004h22llaqss7tuf	2026-09-03 09:41:06.822	2026-09-03 09:41:27.802	\N	\N	\N
cmt8lx48z002622llunvh8x1p	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787658840160-Poteauygraphies--12.jpg	uploads/1787658840160-Poteauygraphies--12.jpg	10	cmt8lu9lb001r22ll1tl78jtv	2026-08-25 11:54:04.355	2026-08-27 08:47:19.653	\N	\N	\N
cmt8lx44e001z22lly2t56vof	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787658840169-Poteauygraphies--14.jpg	uploads/1787658840169-Poteauygraphies--14.jpg	11	cmt8lu9lb001r22ll1tl78jtv	2026-08-25 11:54:04.19	2026-08-27 08:47:19.654	\N	\N	\N
cmt8lx3jx001s22ll3f41o4yu	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787658840181-Poteauygraphies-.jpg	uploads/1787658840181-Poteauygraphies-.jpg	14	cmt8lu9lb001r22ll1tl78jtv	2026-08-25 11:54:03.453	2026-08-27 08:47:19.655	\N	\N	\N
cmt8lx488002522ll94yqafb3	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787658840184-Poteauygraphies-1.jpg	uploads/1787658840184-Poteauygraphies-1.jpg	15	cmt8lu9lb001r22ll1tl78jtv	2026-08-25 11:54:04.328	2026-08-27 08:47:19.655	\N	\N	\N
cmt8lx47n002422ll5587k2wh	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787658840150-Poteauygraphies--11.jpg	uploads/1787658840150-Poteauygraphies--11.jpg	17	cmt8lu9lb001r22ll1tl78jtv	2026-08-25 11:54:04.307	2026-08-27 08:47:19.656	\N	\N	\N
cmt7i2l8b000p22llkekwhkxy	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787591913406-st.-david-002-italie-selection-2000-dpi-jpg-2.jpg	uploads/1787591913406-st.-david-002-italie-selection-2000-dpi-jpg-2.jpg	1	cmt7i1iaq000322lly1wd99fe	2026-08-24 17:18:35.003	2026-08-24 17:27:35.637	\N	\N	\N
cmt7i2l77000j22llocv2mx7z	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787591913410-St.-italie-selection-2000-dpi-jpg-24.jpg	uploads/1787591913410-St.-italie-selection-2000-dpi-jpg-24.jpg	9	cmt7i1iaq000322lly1wd99fe	2026-08-24 17:18:34.963	2026-08-24 17:27:35.645	\N	\N	\N
cmt7i2l2e000a22llatqkzjnq	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787591913325-Fontaine-Tr-vi-Rome-.jpg	uploads/1787591913325-Fontaine-Tr-vi-Rome-.jpg	4	cmt7i1iaq000322lly1wd99fe	2026-08-24 17:18:34.79	2026-08-24 17:27:35.64	\N	\N	\N
cmt7i2l71000i22lljbwc6g62	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787591913411-St.-italie-selection-2000-dpi-jpg-42.jpg	uploads/1787591913411-St.-italie-selection-2000-dpi-jpg-42.jpg	7	cmt7i1iaq000322lly1wd99fe	2026-08-24 17:18:34.959	2026-08-24 17:27:35.644	\N	\N	\N
cmt7i2l67000h22llzdtuyt7e	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787591913366-0120Pu.-florence-italie-selection-2000-dpi-jpg-3.jpg	uploads/1787591913366-0120Pu.-florence-italie-selection-2000-dpi-jpg-3.jpg	13	cmt7i1iaq000322lly1wd99fe	2026-08-24 17:18:34.927	2026-08-24 17:27:35.646	\N	\N	\N
cmt8lx49q002822lld9e4s7lk	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787658840135-Poteauygraphies--5.jpg	uploads/1787658840135-Poteauygraphies--5.jpg	24	cmt8lu9lb001r22ll1tl78jtv	2026-08-25 11:54:04.383	2026-08-27 08:47:19.661	\N	\N	\N
cmt8lx49d002722lli1rbx6yf	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787658840205-Poteauygraphies-01116.jpg	uploads/1787658840205-Poteauygraphies-01116.jpg	22	cmt8lu9lb001r22ll1tl78jtv	2026-08-25 11:54:04.369	2026-08-27 08:47:19.66	\N	\N	\N
cmtssamne008b22ll0ybcxdh3	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788878875544-NDG-vieux-port.jxl	uploads/1788878875544-NDG-vieux-port.jxl	2	cmthvob3v005j22llw2pmotim	2026-09-08 14:47:55.946	2026-09-09 20:05:58.225	\N	\N	\N
cmt8ds7af001822llqyu191qt	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787645176712-Le-voyage-m-diterran-en-1-2.jpg	uploads/1787645176712-Le-voyage-m-diterran-en-1-2.jpg	0	cmt8drvac001222llau5y0lwi	2026-08-25 08:06:18.087	2026-08-25 20:24:05.708	\N	\N	\N
cmt8ds7bg001a22ll9f438k7u	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787645176702-Le-voyage-m-diterran-en--7.jpg	uploads/1787645176702-Le-voyage-m-diterran-en--7.jpg	5	cmt8drvac001222llau5y0lwi	2026-08-25 08:06:18.124	2026-08-25 20:24:05.715	\N	\N	\N
cmt8ds7dk001f22ll1assa6mw	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787645176706-Le-voyage-m-diterran-en--11.jpg	uploads/1787645176706-Le-voyage-m-diterran-en--11.jpg	11	cmt8drvac001222llau5y0lwi	2026-08-25 08:06:18.201	2026-08-25 20:24:05.719	\N	\N	\N
cmt8ds7cb001b22llxojltzz4	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787645176705-Le-voyage-m-diterran-en--9.jpg	uploads/1787645176705-Le-voyage-m-diterran-en--9.jpg	15	cmt8drvac001222llau5y0lwi	2026-08-25 08:06:18.155	2026-08-25 20:24:05.72	\N	\N	\N
cmt8ds7d1001d22lleidu787g	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787645176722-Le-voyage-m-diterran-en-02.jpg	uploads/1787645176722-Le-voyage-m-diterran-en-02.jpg	16	cmt8drvac001222llau5y0lwi	2026-08-25 08:06:18.181	2026-08-25 20:24:05.721	\N	\N	\N
cmt8lx412001x22ll3z2xnri4	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787658840192-Poteauygraphies-2-3.jpg	uploads/1787658840192-Poteauygraphies-2-3.jpg	18	cmt8lu9lb001r22ll1tl78jtv	2026-08-25 11:54:04.07	2026-08-27 08:47:19.656	\N	\N	\N
cmt5uzrjf000i22pmrnq5t8xi	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787492683521-016-Germaine-et-ses-chiens-.jpg	uploads/1787492683521-016-Germaine-et-ses-chiens-.jpg	14	cmt5ux60t000f22pmb6l0ko8q	2026-08-23 13:44:45.867	2026-08-23 13:47:20.189	\N	\N	\N
cmt8v9hoj002w22ll1odcz2a4	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787674535319-Orta-cadre-vide-.jpg	uploads/1787674535319-Orta-cadre-vide-.jpg	13	cmt8v8qgb002l22llf0q3b3tx	2026-08-25 16:15:38.179	2026-09-09 22:51:41.728	\N	\N	\N
cmtssncic008c22ll9n544dis	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788879468969-Port-de-l-escalette-01.jxl	uploads/1788879468969-Port-de-l-escalette-01.jxl	18	cmthvob3v005j22llw2pmotim	2026-09-08 14:57:49.332	2026-09-09 20:05:58.234	\N	\N	\N
cmtrffzd1008522ll46im1n8r	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788796823979-P-niche-nuit-port-.jpg	uploads/1788796823979-P-niche-nuit-port-.jpg	19	cmthvob3v005j22llw2pmotim	2026-09-07 16:00:24.517	2026-09-09 20:05:58.234	\N	\N	\N
cmt7i2l8h000q22llwdf5n994	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787591913411-St.-italie-selection-2000-dpi-jpg-47.jpg	uploads/1787591913411-St.-italie-selection-2000-dpi-jpg-47.jpg	8	cmt7i1iaq000322lly1wd99fe	2026-08-24 17:18:35.009	2026-08-24 17:27:35.644	\N	\N	\N
cmt7i2lak000s22ll2o91tfhb	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787591913345-0020-Pu.-italie-selection-2000-dpi-jpg-22.jpg	uploads/1787591913345-0020-Pu.-italie-selection-2000-dpi-jpg-22.jpg	12	cmt7i1iaq000322lly1wd99fe	2026-08-24 17:18:35.084	2026-08-24 17:27:35.646	\N	\N	\N
cmt7i2l3j000e22ll4e1w7xly	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787591913403-poteau--prairie-lac-c-me-.jpg	uploads/1787591913403-poteau--prairie-lac-c-me-.jpg	16	cmt7i1iaq000322lly1wd99fe	2026-08-24 17:18:34.831	2026-08-24 17:27:35.646	\N	\N	\N
cmt7i2l0s000522lljdr4dkag	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787591913394-Le-lac-de-C-me-2000.jpg	uploads/1787591913394-Le-lac-de-C-me-2000.jpg	18	cmt7i1iaq000322lly1wd99fe	2026-08-24 17:18:34.732	2026-08-24 17:27:35.647	\N	\N	\N
cmt7i2l7c000l22ll6ktsi8th	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787591913404-Roma-Fiat-.jpg	uploads/1787591913404-Roma-Fiat-.jpg	28	cmt7i1iaq000322lly1wd99fe	2026-08-24 17:18:34.968	2026-08-24 17:27:35.65	\N	\N	\N
cmt8ds79j001422llhqbtevcz	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787645176705-Le-voyage-m-diterran-en--10.jpg	uploads/1787645176705-Le-voyage-m-diterran-en--10.jpg	2	cmt8drvac001222llau5y0lwi	2026-08-25 08:06:18.055	2026-08-25 20:24:05.711	\N	\N	\N
cmt8lx4bw002c22llszj9ubuf	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787658840150-Poteauygraphies--10.jpg	uploads/1787658840150-Poteauygraphies--10.jpg	9	cmt8lu9lb001r22ll1tl78jtv	2026-08-25 11:54:04.46	2026-08-27 08:47:19.652	\N	\N	\N
cmt8lx4a4002922ll96leuoxw	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787658840131-Poteauygraphies--3.jpg	uploads/1787658840131-Poteauygraphies--3.jpg	5	cmt8lu9lb001r22ll1tl78jtv	2026-08-25 11:54:04.396	2026-08-27 08:47:19.648	\N	\N	\N
cmt8lx4f7002e22llthbunk2q	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787658840145-Poteauygraphies--9.jpg	uploads/1787658840145-Poteauygraphies--9.jpg	3	cmt8lu9lb001r22ll1tl78jtv	2026-08-25 11:54:04.579	2026-08-27 08:47:19.647	\N	\N	\N
cmt8lx4dn002d22llsl9ipapb	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787658840170-Poteauygraphies--15.jpg	uploads/1787658840170-Poteauygraphies--15.jpg	12	cmt8lu9lb001r22ll1tl78jtv	2026-08-25 11:54:04.523	2026-08-27 08:47:19.655	\N	\N	\N
cmt8lx4bb002b22llqjwjx5dt	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787658840176-Poteauygraphies--16.jpg	uploads/1787658840176-Poteauygraphies--16.jpg	13	cmt8lu9lb001r22ll1tl78jtv	2026-08-25 11:54:04.439	2026-08-27 08:47:19.655	\N	\N	\N
cmt5uzrqg000r22pmyb0tx8ok	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787492683529-003-Germaine-fa-ade-.jpg	uploads/1787492683529-003-Germaine-fa-ade-.jpg	1	cmt5ux60t000f22pmb6l0ko8q	2026-08-23 13:44:46.12	2026-08-23 13:47:20.182	\N	\N	\N
cmt5uzrlr000m22pma9pz8dbs	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787492683529-002-Germaine--jpg.jpg	uploads/1787492683529-002-Germaine--jpg.jpg	0	cmt5ux60t000f22pmb6l0ko8q	2026-08-23 13:44:45.951	2026-08-23 13:47:20.18	\N	\N	\N
cmt5uzruz000s22pmsci9kr02	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787492683521-005-jpg.jpg	uploads/1787492683521-005-jpg.jpg	13	cmt5ux60t000f22pmb6l0ko8q	2026-08-23 13:44:46.283	2026-08-23 13:47:20.189	\N	\N	\N
cmt5uzrys000u22pmsutljga4	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787492683526-008-ermaine-fenetre-bar-.jpg	uploads/1787492683526-008-ermaine-fenetre-bar-.jpg	4	cmt5ux60t000f22pmb6l0ko8q	2026-08-23 13:44:46.42	2026-08-23 13:47:20.184	\N	\N	\N
cmt5uzryb000t22pmwgua377f	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787492683520-015-Nord-Pinus-le-bar-2.jpg	uploads/1787492683520-015-Nord-Pinus-le-bar-2.jpg	5	cmt5ux60t000f22pmb6l0ko8q	2026-08-23 13:44:46.403	2026-08-23 13:47:20.185	\N	\N	\N
cmt5uzrny000p22pm10nmzenc	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787492683524-009-Germaine-cuisine-.jpg	uploads/1787492683524-009-Germaine-cuisine-.jpg	9	cmt5ux60t000f22pmb6l0ko8q	2026-08-23 13:44:46.03	2026-08-23 13:47:20.187	\N	\N	\N
cmtsixkoe008622llzwaet1e7	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788863150017-L-ile-aux-pendus.jpg	uploads/1788863150017-L-ile-aux-pendus.jpg	10	cmthvob3v005j22llw2pmotim	2026-09-08 10:25:50.318	2026-09-09 20:05:58.233	\N	\N	\N
cmtt680hq008d22llke6ccrgj	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788902268133-Daniel-cazanova-copie.jxl	uploads/1788902268133-Daniel-cazanova-copie.jxl	20	cmthvob3v005j22llw2pmotim	2026-09-08 21:17:48.543	2026-09-09 20:05:58.234	\N	\N	\N
cmt5vpew4001522pmko3xc3r9	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787493879305-13-Moinillon-8619.jpg	uploads/1787493879305-13-Moinillon-8619.jpg	10	cmt5vm22w000v22pmd3mmrqe8	2026-08-23 14:04:42.532	2026-08-23 14:14:59.985	\N	\N	\N
cmt5vpf27001a22pmwjedi098	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787493879300-06-chapelle-VXIII-2103.jpg	uploads/1787493879300-06-chapelle-VXIII-2103.jpg	3	cmt5vm22w000v22pmd3mmrqe8	2026-08-23 14:04:42.751	2026-08-23 14:14:59.979	\N	\N	\N
cmt5vpeu9001022pmqrf4l087	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787493879309-15-.jpg	uploads/1787493879309-15-.jpg	12	cmt5vm22w000v22pmd3mmrqe8	2026-08-23 14:04:42.465	2026-08-23 14:14:59.985	\N	\N	\N
cmt5vpf95001f22pm9mqi16wz	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787493879306-04-Chapelle--Orta-VI-2115.jpg	uploads/1787493879306-04-Chapelle--Orta-VI-2115.jpg	1	cmt5vm22w000v22pmd3mmrqe8	2026-08-23 14:04:43.001	2026-08-23 14:14:59.978	\N	\N	\N
cmt5vpelb000x22pmdt157jld	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787493879313-16-Portrait-l-preux-03.jpg	uploads/1787493879313-16-Portrait-l-preux-03.jpg	13	cmt5vm22w000v22pmd3mmrqe8	2026-08-23 14:04:42.143	2026-08-23 14:14:59.987	\N	\N	\N
cmt5vpff8001h22pmqyv2lspl	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787493879304-05-chapelle-Vii-5229.jpg	uploads/1787493879304-05-chapelle-Vii-5229.jpg	2	cmt5vm22w000v22pmd3mmrqe8	2026-08-23 14:04:43.22	2026-08-23 14:14:59.979	\N	\N	\N
cmt5vpedv000w22pmexy386tf	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787493879314-17-Femme-et-p-re-Rembrant-01.jpg	uploads/1787493879314-17-Femme-et-p-re-Rembrant-01.jpg	14	cmt5vm22w000v22pmd3mmrqe8	2026-08-23 14:04:41.875	2026-08-23 14:14:59.987	\N	\N	\N
cmt5vpevt001422pmt0yq76s5	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787493879306-12-Vielle-dame-5286.jpg	uploads/1787493879306-12-Vielle-dame-5286.jpg	9	cmt5vm22w000v22pmd3mmrqe8	2026-08-23 14:04:42.521	2026-08-23 14:14:59.984	\N	\N	\N
cmt5vpf85001e22pm9uaczj3r	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787493879309-21-Orta-Chap-XXI-.jpg	uploads/1787493879309-21-Orta-Chap-XXI-.jpg	18	cmt5vm22w000v22pmd3mmrqe8	2026-08-23 14:04:42.965	2026-08-23 14:14:59.988	\N	\N	\N
cmt5vpelk000y22pmqagfdfws	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787493879306-22-Chien-Or-ta-8527.jpg	uploads/1787493879306-22-Chien-Or-ta-8527.jpg	19	cmt5vm22w000v22pmd3mmrqe8	2026-08-23 14:04:42.152	2026-08-23 14:14:59.988	\N	\N	\N
cmt5vpf5k001b22pmthst1ydn	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787493879307-23-vue-arriere-XXI-8626.jpg	uploads/1787493879307-23-vue-arriere-XXI-8626.jpg	20	cmt5vm22w000v22pmd3mmrqe8	2026-08-23 14:04:42.872	2026-08-23 14:14:59.989	\N	\N	\N
cmt5vpey3001822pmnh0rtv3e	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787493879313-24-Portrait-l-preux-22.jpg	uploads/1787493879313-24-Portrait-l-preux-22.jpg	22	cmt5vm22w000v22pmd3mmrqe8	2026-08-23 14:04:42.603	2026-08-23 14:14:59.989	\N	\N	\N
cmt8ds79o001522ll3prw8vag	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787645176704-Le-voyage-m-diterran-en--8.jpg	uploads/1787645176704-Le-voyage-m-diterran-en--8.jpg	8	cmt8drvac001222llau5y0lwi	2026-08-25 08:06:18.06	2026-08-25 20:24:05.717	\N	\N	\N
cmt8lx3wk001t22llujaejidl	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787658840197-Poteauygraphies-2.jpg	uploads/1787658840197-Poteauygraphies-2.jpg	6	cmt8lu9lb001r22ll1tl78jtv	2026-08-25 11:54:03.908	2026-08-27 08:47:19.649	\N	\N	\N
cmt7i2l7r000m22llflx9o7ha	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787591913356-098-ET-SI-OMNES--etape110297-08-29.jpg	uploads/1787591913356-098-ET-SI-OMNES--etape110297-08-29.jpg	17	cmt7i1iaq000322lly1wd99fe	2026-08-24 17:18:34.983	2026-08-24 17:27:35.647	\N	\N	\N
cmt7i2lch000u22llv0kdbhwm	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787591913390-Genes-vespa-01.jpg	uploads/1787591913390-Genes-vespa-01.jpg	29	cmt7i1iaq000322lly1wd99fe	2026-08-24 17:18:35.153	2026-08-24 17:27:35.65	\N	\N	\N
cmt5vpfgq001i22pm3nglcr9r	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787493879304-03-Lac-d-orta-01-2362.jpg	uploads/1787493879304-03-Lac-d-orta-01-2362.jpg	0	cmt5vm22w000v22pmd3mmrqe8	2026-08-23 14:04:43.274	2026-08-23 14:14:59.976	\N	\N	\N
cmt7i2lkw000z22ll9o63w3m0	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787591913407-st.-david-003--italie-selection-2000-dpi-jpg.jpg	uploads/1787591913407-st.-david-003--italie-selection-2000-dpi-jpg.jpg	3	cmt7i1iaq000322lly1wd99fe	2026-08-24 17:18:35.456	2026-08-24 17:27:35.639	\N	\N	\N
cmt7i2l2v000c22ll02nckcsa	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787591913411-St.-italie-selection-2000-dpi-jpg-40.jpg	uploads/1787591913411-St.-italie-selection-2000-dpi-jpg-40.jpg	5	cmt7i1iaq000322lly1wd99fe	2026-08-24 17:18:34.807	2026-08-24 17:27:35.642	\N	\N	\N
cmt7i2lk9000x22ll57tf0rh3	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787591913351-095-Pa.-italie-selection-2000-dpi-jpg-111.jpg	uploads/1787591913351-095-Pa.-italie-selection-2000-dpi-jpg-111.jpg	14	cmt7i1iaq000322lly1wd99fe	2026-08-24 17:18:35.433	2026-08-24 17:27:35.646	\N	\N	\N
cmt7i2ldl000v22llen3vxozg	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787591913394-La-mari-e-rome-2008.jpg	uploads/1787591913394-La-mari-e-rome-2008.jpg	24	cmt7i1iaq000322lly1wd99fe	2026-08-24 17:18:35.193	2026-08-24 17:27:35.649	\N	\N	\N
cmt7i2lgl000w22ll3xlsszc3	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787591913412-Villa-carlotta-2015.jpg	uploads/1787591913412-Villa-carlotta-2015.jpg	30	cmt7i1iaq000322lly1wd99fe	2026-08-24 17:18:35.301	2026-08-24 17:27:35.65	\N	\N	\N
cmt8lx4ih002h22ll8skx9u0g	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787658840131-Poteauygraphies--4.jpg	uploads/1787658840131-Poteauygraphies--4.jpg	7	cmt8lu9lb001r22ll1tl78jtv	2026-08-25 11:54:04.697	2026-08-27 08:47:19.65	\N	\N	\N
cmt8v9hpm002y22llyfzkq1nt	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787674535308--mus-um-cadre-.jpg	uploads/1787674535308--mus-um-cadre-.jpg	11	cmt8v8qgb002l22llf0q3b3tx	2026-08-25 16:15:38.219	2026-09-09 22:51:41.726	\N	\N	\N
cmtt683mx008e22llcvyqiypy	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788902272289-Daniel-cazanova-copie.jxl	uploads/1788902272289-Daniel-cazanova-copie.jxl	5	cmthvob3v005j22llw2pmotim	2026-09-08 21:17:52.617	2026-09-09 20:05:58.228	\N	\N	\N
cmt8v9hmr002u22llbadaeknf	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787674535322-peyrassol-3.jpg	uploads/1787674535322-peyrassol-3.jpg	0	cmt8v8qgb002l22llf0q3b3tx	2026-08-25 16:15:38.116	2026-09-09 22:51:41.706	\N	\N	\N
cmtw3mapv009022llhhmn32sw	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1789079294222-cours-ju-poteau-2.jxl	uploads/1789079294222-cours-ju-poteau-2.jxl	5	cmttryl6q008f22llf3beyozg	2026-09-10 22:28:14.659	2026-09-10 22:30:46.282	\N	\N	\N
cmt8v9hlz002r22llkxb5gxiq	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787674535312-Da-Sergio-.jpg	uploads/1787674535312-Da-Sergio-.jpg	2	cmt8v8qgb002l22llf0q3b3tx	2026-08-25 16:15:38.087	2026-09-09 22:51:41.715	\N	\N	\N
cmt8v9hl7002q22llae8waxv0	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787674535312-courbet-2-amies-2.jpg	uploads/1787674535312-courbet-2-amies-2.jpg	5	cmt8v8qgb002l22llf0q3b3tx	2026-08-25 16:15:38.059	2026-09-09 22:51:41.719	\N	\N	\N
cmt7i2lko000y22llf20bftkq	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787591913406-St.-david-001-italie-selection-2000-dpi-jpg-53.jpg	uploads/1787591913406-St.-david-001-italie-selection-2000-dpi-jpg-53.jpg	0	cmt7i1iaq000322lly1wd99fe	2026-08-24 17:18:35.448	2026-08-24 17:27:35.636	\N	\N	\N
cmt8vwtap003722llqeq0j8zi	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787675625406-New-york-hooper-10008.jpg	uploads/1787675625406-New-york-hooper-10008.jpg	1	cmt8vvwh4003222ll1xuw3fqh	2026-08-25 16:33:46.321	2026-08-25 16:34:59.312	\N	\N	\N
cmt8vwtx7003922ll8iz1w9em	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787675625405-New-york-5e-av-manequin-RCA-.jpg	uploads/1787675625405-New-york-5e-av-manequin-RCA-.jpg	4	cmt8vvwh4003222ll1xuw3fqh	2026-08-25 16:33:47.131	2026-08-25 16:34:59.314	\N	\N	\N
cmt8vwtf7003822llrloz9g86	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787675625407-New-york-ombre-.jpg	uploads/1787675625407-New-york-ombre-.jpg	5	cmt8vvwh4003222ll1xuw3fqh	2026-08-25 16:33:46.483	2026-08-25 16:34:59.314	\N	\N	\N
cmt8vwt8h003522llggtbgqr0	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787675625406-New-york-hooper-bis-10008.jpg	uploads/1787675625406-New-york-hooper-bis-10008.jpg	2	cmt8vvwh4003222ll1xuw3fqh	2026-08-25 16:33:46.241	2026-08-25 16:34:59.313	\N	\N	\N
cmt8ds79r001622llekj0qy7g	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787645176701-Le-voyage-m-diterran-en--6.jpg	uploads/1787645176701-Le-voyage-m-diterran-en--6.jpg	1	cmt8drvac001222llau5y0lwi	2026-08-25 08:06:18.063	2026-08-25 20:24:05.709	\N	\N	\N
cmt8ds7go001j22llmslv1n63	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787645176709-Le-voyage-m-diterran-en--14.jpg	uploads/1787645176709-Le-voyage-m-diterran-en--14.jpg	6	cmt8drvac001222llau5y0lwi	2026-08-25 08:06:18.312	2026-08-25 20:24:05.716	\N	\N	\N
cmtaq8d5n003m22ll74qsz2ik	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787787017150-hommage---Delacroix-.jpg	uploads/1787787017150-hommage---Delacroix-.jpg	2	cmtaq6dvr003b22ll1sv8lyww	2026-08-26 23:30:19.931	2026-08-26 23:56:14.444	\N	\N	\N
cmt8lx3yb001w22ll9bno1b0d	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787658840205-Poteauygraphies-2005.jpg	uploads/1787658840205-Poteauygraphies-2005.jpg	23	cmt8lu9lb001r22ll1tl78jtv	2026-08-25 11:54:03.975	2026-08-27 08:47:19.661	\N	\N	\N
cmtaq8cx7003c22lliz3u5qpw	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787787017242-PA.Mus-e-d-art-moderne.bis-2.jpg	uploads/1787787017242-PA.Mus-e-d-art-moderne.bis-2.jpg	13	cmtaq6dvr003b22ll1sv8lyww	2026-08-26 23:30:19.627	2026-08-26 23:56:14.446	\N	\N	\N
cmtaq8d1p003h22llznytbvk4	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787787017169-PA.L-origine-du-monde.-.jpg	uploads/1787787017169-PA.L-origine-du-monde.-.jpg	5	cmtaq6dvr003b22ll1sv8lyww	2026-08-26 23:30:19.789	2026-08-26 23:56:14.445	\N	\N	\N
cmt8v9hq4003022llj51msszd	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787674535310-chie-puces-2.jpg	uploads/1787674535310-chie-puces-2.jpg	7	cmt8v8qgb002l22llf0q3b3tx	2026-08-25 16:15:38.236	2026-09-09 22:51:41.721	\N	\N	\N
cmt8v9hpi002x22ll2240bate	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787674535319-meg-ves-.jpg	uploads/1787674535319-meg-ves-.jpg	8	cmt8v8qgb002l22llf0q3b3tx	2026-08-25 16:15:38.214	2026-09-09 22:51:41.721	\N	\N	\N
cmt5vpev0001122pmhs8t3sy0	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787493879314-14-Orta-femme-Lacroix-christian-12.jpg	uploads/1787493879314-14-Orta-femme-Lacroix-christian-12.jpg	11	cmt5vm22w000v22pmd3mmrqe8	2026-08-23 14:04:42.492	2026-08-23 14:14:59.985	\N	\N	\N
cmt5vpeyw001922pm4n17d0a8	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787493879312-08-Enfant-chien-2-.jpg	uploads/1787493879312-08-Enfant-chien-2-.jpg	5	cmt5vm22w000v22pmd3mmrqe8	2026-08-23 14:04:42.633	2026-08-23 14:14:59.98	\N	\N	\N
cmt5vpf7x001d22pm2hjgx4oo	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787493879312-18-Diablesse-2-15.jpg	uploads/1787493879312-18-Diablesse-2-15.jpg	15	cmt5vm22w000v22pmd3mmrqe8	2026-08-23 14:04:42.957	2026-08-23 14:14:59.988	\N	\N	\N
cmt5vpfdr001g22pmu4jaiew6	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787493879309-10-Orta-Chap-retour-Egypte-5262.jpg	uploads/1787493879309-10-Orta-Chap-retour-Egypte-5262.jpg	7	cmt5vm22w000v22pmd3mmrqe8	2026-08-23 14:04:43.17	2026-08-23 14:14:59.982	\N	\N	\N
cmt5vpene000z22pmi1k0s6p7	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787493879311-07-Panorama-couv-.jpg	uploads/1787493879311-07-Panorama-couv-.jpg	4	cmt5vm22w000v22pmd3mmrqe8	2026-08-23 14:04:42.218	2026-08-23 14:14:59.98	\N	\N	\N
cmt5vpf6o001c22pmk3rrzgae	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787493879305-09-Chapelle--enfant-chien-01-.jpg	uploads/1787493879305-09-Chapelle--enfant-chien-01-.jpg	6	cmt5vm22w000v22pmd3mmrqe8	2026-08-23 14:04:42.912	2026-08-23 14:14:59.981	\N	\N	\N
cmt5vpeve001322pm5mlfrll0	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787493879309-11-chapelle-panorama-.jpg	uploads/1787493879309-11-chapelle-panorama-.jpg	8	cmt5vm22w000v22pmd3mmrqe8	2026-08-23 14:04:42.506	2026-08-23 14:14:59.984	\N	\N	\N
cmt5vpewh001722pmjossokck	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787493879312-19-Cheval-surgissant-.jpg	uploads/1787493879312-19-Cheval-surgissant-.jpg	16	cmt5vm22w000v22pmd3mmrqe8	2026-08-23 14:04:42.545	2026-08-23 14:14:59.988	\N	\N	\N
cmt5vpewb001622pmsf7jsj7u	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787493879314-20-Femme-et-bandit-lubrique.jpg	uploads/1787493879314-20-Femme-et-bandit-lubrique.jpg	17	cmt5vm22w000v22pmd3mmrqe8	2026-08-23 14:04:42.539	2026-08-23 14:14:59.988	\N	\N	\N
cmt5vpev7001222pmxv9gfyxw	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787493879306-24-Autoportrait-orta-XXI-0273.jpg	uploads/1787493879306-24-Autoportrait-orta-XXI-0273.jpg	21	cmt5vm22w000v22pmd3mmrqe8	2026-08-23 14:04:42.499	2026-08-23 14:14:59.989	\N	\N	\N
cmtsk7nrm008822llo9bts1my	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788865300203-Les-goudes-nuit-verte.jpg	uploads/1788865300203-Les-goudes-nuit-verte.jpg	25	cmthvob3v005j22llw2pmotim	2026-09-08 11:01:40.498	2026-09-09 20:05:58.235	\N	\N	\N
cmt7i2lbh000t22lln8f3bml0	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787591913385-faux-semblant-05-2000.jpg	uploads/1787591913385-faux-semblant-05-2000.jpg	20	cmt7i1iaq000322lly1wd99fe	2026-08-24 17:18:35.117	2026-08-24 17:27:35.649	\N	\N	\N
cmt8lx4l5002i22lluh7nhpbm	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787658840192-Poteauygraphies-2-4.jpg	uploads/1787658840192-Poteauygraphies-2-4.jpg	19	cmt8lu9lb001r22ll1tl78jtv	2026-08-25 11:54:04.794	2026-08-27 08:47:19.659	\N	\N	\N
cmt8v9hrw003122llo7wyr89o	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787674535309-casre-dor--Lascours-3.jpg	uploads/1787674535309-casre-dor--Lascours-3.jpg	1	cmt8v8qgb002l22llf0q3b3tx	2026-08-25 16:15:38.3	2026-09-09 22:51:41.713	\N	\N	\N
cmt8v9hpw002z22llbbet710u	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787674535317-Germaine-.jpg	uploads/1787674535317-Germaine-.jpg	6	cmt8v8qgb002l22llf0q3b3tx	2026-08-25 16:15:38.228	2026-09-09 22:51:41.72	\N	\N	\N
cmt8v9hm4002s22lloaa2z7je	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787674535310-c-zanne-cadre--curies-3.jpg	uploads/1787674535310-c-zanne-cadre--curies-3.jpg	14	cmt8v8qgb002l22llf0q3b3tx	2026-08-25 16:15:38.092	2026-09-09 22:51:41.732	\N	\N	\N
cmtts18ab008g22ll8qt9hhel	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788938902825-Valmante.jxl	uploads/1788938902825-Valmante.jxl	0	cmttryl6q008f22llf3beyozg	2026-09-09 07:28:23.603	2026-09-10 22:30:46.278	\N	\N	\N
cmt8v9hhl002o22lligs7m010	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787674535321-Orta-cadre-vide-3.jpg	uploads/1787674535321-Orta-cadre-vide-3.jpg	9	cmt8v8qgb002l22llf0q3b3tx	2026-08-25 16:15:37.929	2026-09-09 22:51:41.725	\N	\N	\N
cmt8vwt8t003622llu1zgrwuc	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787675625407-New-york-no-parking-2.jpg	uploads/1787675625407-New-york-no-parking-2.jpg	0	cmt8vvwh4003222ll1xuw3fqh	2026-08-25 16:33:46.253	2026-08-25 16:34:59.311	\N	\N	\N
cmt8vwt5i003322ll5hqp0o9h	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787675625407-New-york-trade-center-1977.jpg	uploads/1787675625407-New-york-trade-center-1977.jpg	3	cmt8vvwh4003222ll1xuw3fqh	2026-08-25 16:33:46.134	2026-08-25 16:34:59.313	\N	\N	\N
cmt8ds7d7001e22llqm2pw6hn	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787645176716-Le-voyage-m-diterran-en-1-3.jpg	uploads/1787645176716-Le-voyage-m-diterran-en-1-3.jpg	7	cmt8drvac001222llau5y0lwi	2026-08-25 08:06:18.187	2026-08-25 20:24:05.716	\N	\N	\N
cmt8ds7al001922llz3d376nh	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787645176712-Le-voyage-m-diterran-en-.jpg	uploads/1787645176712-Le-voyage-m-diterran-en-.jpg	17	cmt8drvac001222llau5y0lwi	2026-08-25 08:06:18.093	2026-08-25 20:24:05.723	\N	\N	\N
cmtaq8cxo003e22llkbfgumie	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787787017273-PA.Richter-Beaubourg.-.jpg	uploads/1787787017273-PA.Richter-Beaubourg.-.jpg	14	cmtaq6dvr003b22ll1sv8lyww	2026-08-26 23:30:19.644	2026-08-26 23:56:14.446	\N	\N	\N
cmt8lx47a002322lliftabyqs	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787658840140-Poteauygraphies--7.jpg	uploads/1787658840140-Poteauygraphies--7.jpg	1	cmt8lu9lb001r22ll1tl78jtv	2026-08-25 11:54:04.295	2026-08-27 08:47:19.644	\N	\N	\N
cmt8lx4qt002j22llvuaahq0e	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787658840127-Poteauygraphies--2.jpg	uploads/1787658840127-Poteauygraphies--2.jpg	4	cmt8lu9lb001r22ll1tl78jtv	2026-08-25 11:54:04.997	2026-08-27 08:47:19.648	\N	\N	\N
cmt8v9hm8002t22llqjafsxcg	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787674535319-guicheti-re-2.jpg	uploads/1787674535319-guicheti-re-2.jpg	12	cmt8v8qgb002l22llf0q3b3tx	2026-08-25 16:15:38.096	2026-09-09 22:51:41.726	\N	\N	\N
cmtaq8d2q003j22ll826tupnm	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787787017174-PA.La-lectrice-affol-e.-.jpg	uploads/1787787017174-PA.La-lectrice-affol-e.-.jpg	6	cmtaq6dvr003b22ll1sv8lyww	2026-08-26 23:30:19.826	2026-08-26 23:56:14.445	\N	\N	\N
cmt8v9hhw002p22llefbeayad	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787674535314-da-sergio-3.jpg	uploads/1787674535314-da-sergio-3.jpg	3	cmt8v8qgb002l22llf0q3b3tx	2026-08-25 16:15:37.94	2026-09-09 22:51:41.715	\N	\N	\N
cmt7i2l8q000r22ll24b2gat9	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787591913393-Italie-Bergame--1-sur-1-.jpg	uploads/1787591913393-Italie-Bergame--1-sur-1-.jpg	21	cmt7i1iaq000322lly1wd99fe	2026-08-24 17:18:35.018	2026-08-24 17:27:35.649	\N	\N	\N
cmt7i2l1s000722llbnhmnhrg	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787591913412-Stv.-italie-selection-2000-dpi-jpg-3.jpg	uploads/1787591913412-Stv.-italie-selection-2000-dpi-jpg-3.jpg	27	cmt7i1iaq000322lly1wd99fe	2026-08-24 17:18:34.768	2026-08-24 17:27:35.649	\N	\N	\N
cmt8lx44i002022llfwesrsvp	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787658840185-Poteauygraphies-2-2.jpg	uploads/1787658840185-Poteauygraphies-2-2.jpg	16	cmt8lu9lb001r22ll1tl78jtv	2026-08-25 11:54:04.194	2026-08-27 08:47:19.655	\N	\N	\N
cmt8lx3xv001v22llwop2lo5u	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787658840196-Poteauygraphies-2-5.jpg	uploads/1787658840196-Poteauygraphies-2-5.jpg	20	cmt8lu9lb001r22ll1tl78jtv	2026-08-25 11:54:03.955	2026-08-27 08:47:19.659	\N	\N	\N
cmt8v9hfu002m22llup5tmcoq	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787674535323-St-victoite-poteau-blanc-2.jpg	uploads/1787674535323-St-victoite-poteau-blanc-2.jpg	16	cmt8v8qgb002l22llf0q3b3tx	2026-08-25 16:15:37.866	2026-09-09 22:51:41.732	\N	\N	\N
cmt8vwt61003422llssoq4x0h	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787675625405-New-york-1977-.jpg	uploads/1787675625405-New-york-1977-.jpg	6	cmt8vvwh4003222ll1xuw3fqh	2026-08-25 16:33:46.153	2026-08-25 16:34:59.314	\N	\N	\N
cmt8ds7fl001i22ll8ffq26ie	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787645176699-Le-voyage-m-diterran-en--2.jpg	uploads/1787645176699-Le-voyage-m-diterran-en--2.jpg	3	cmt8drvac001222llau5y0lwi	2026-08-25 08:06:18.273	2026-08-25 20:24:05.711	\N	\N	\N
cmt944l2b003a22llx1d5jkn4	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787689425374-Mekn-s-02-.jpg	uploads/1787689425374-Mekn-s-02-.jpg	9	cmt8drvac001222llau5y0lwi	2026-08-25 20:23:45.827	2026-08-25 20:24:05.718	\N	\N	\N
cmt8ds7ia001l22ll6k1p496x	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787645176707-Le-voyage-m-diterran-en--13.jpg	uploads/1787645176707-Le-voyage-m-diterran-en--13.jpg	12	cmt8drvac001222llau5y0lwi	2026-08-25 08:06:18.37	2026-08-25 20:24:05.719	\N	\N	\N
cmtts2cej008h22llx28p8z3h	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788938955158-Super-Rouvi-re.jxl	uploads/1788938955158-Super-Rouvi-re.jxl	1	cmttryl6q008f22llf3beyozg	2026-09-09 07:29:15.595	2026-09-10 22:30:46.279	\N	\N	\N
cmtts2kah008i22llw17r9yno	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788938965381-Super-Rouvi-re.jxl	uploads/1788938965381-Super-Rouvi-re.jxl	2	cmttryl6q008f22llf3beyozg	2026-09-09 07:29:25.817	2026-09-10 22:30:46.28	\N	\N	\N
cmtaq8cxb003d22llucrdtpp7	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787787017139-David-Hckney-Nationale-Galerie-Londres-01.jpg	uploads/1787787017139-David-Hckney-Nationale-Galerie-Londres-01.jpg	1	cmtaq6dvr003b22ll1sv8lyww	2026-08-26 23:30:19.631	2026-08-26 23:56:14.444	\N	\N	\N
cmtaq8d3b003k22lle5f73ctv	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787787017225-PA.Mus-e-d-art-moderne-gardien-cach-.bis-5188.jpg	uploads/1787787017225-PA.Mus-e-d-art-moderne-gardien-cach-.bis-5188.jpg	10	cmtaq6dvr003b22ll1sv8lyww	2026-08-26 23:30:19.847	2026-08-26 23:56:14.445	\N	\N	\N
cmtaq8d6c003n22ll76q3dcud	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787787017179-PA.Le-Jean-de-Monet.-.jpg	uploads/1787787017179-PA.Le-Jean-de-Monet.-.jpg	8	cmtaq6dvr003b22ll1sv8lyww	2026-08-26 23:30:19.956	2026-08-26 23:56:14.445	\N	\N	\N
cmtaq8cy1003f22ll4d52kbf7	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787787017159-PA.Granet-C-zanne.-.jpg	uploads/1787787017159-PA.Granet-C-zanne.-.jpg	4	cmtaq6dvr003b22ll1sv8lyww	2026-08-26 23:30:19.657	2026-08-26 23:56:14.444	\N	\N	\N
cmt60di3a002l22pmsma9izy5	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787501724094-9.les-loges-sous-la-sc-ne.jpg	uploads/1787501724094-9.les-loges-sous-la-sc-ne.jpg	8	cmt609lxj002k22pmpgmty1jy	2026-08-23 16:15:24.886	2026-08-23 16:15:24.886	\N	\N	\N
cmt60di3s002n22pm2a74fce2	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787501724093-8.Salle-projection-d-truite.jpg	uploads/1787501724093-8.Salle-projection-d-truite.jpg	7	cmt609lxj002k22pmpgmty1jy	2026-08-23 16:15:24.904	2026-08-23 16:15:24.904	\N	\N	\N
cmt60di3k002m22pmnv9qnb2i	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787501724089-1.Eden-exterieur-cour-9885.jpg	uploads/1787501724089-1.Eden-exterieur-cour-9885.jpg	0	cmt609lxj002k22pmpgmty1jy	2026-08-23 16:15:24.896	2026-08-23 16:15:24.896	\N	\N	\N
cmt60di4d002o22pm315mny8x	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787501724094-11-.Autoportrait---la-caisse.jpg	uploads/1787501724094-11-.Autoportrait---la-caisse.jpg	10	cmt609lxj002k22pmpgmty1jy	2026-08-23 16:15:24.925	2026-08-23 16:15:24.925	\N	\N	\N
cmt60di4f002p22pm4jeco7tz	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787501724091-6.Cabine-de-projection.jpg	uploads/1787501724091-6.Cabine-de-projection.jpg	5	cmt609lxj002k22pmpgmty1jy	2026-08-23 16:15:24.927	2026-08-23 16:15:24.927	\N	\N	\N
cmt60di4h002q22pmzqc715z9	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787501724091-5.Eden-exterieur-nuit.jpg	uploads/1787501724091-5.Eden-exterieur-nuit.jpg	4	cmt609lxj002k22pmpgmty1jy	2026-08-23 16:15:24.929	2026-08-23 16:15:24.929	\N	\N	\N
cmt60di56002r22pm9tppcgcx	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787501724090-2.Eden-exterieur.jpg	uploads/1787501724090-2.Eden-exterieur.jpg	1	cmt609lxj002k22pmpgmty1jy	2026-08-23 16:15:24.954	2026-08-23 16:15:24.954	\N	\N	\N
cmt60di5a002s22pmlh15sp2e	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787501724090-4.Eden-enseigne.jpg	uploads/1787501724090-4.Eden-enseigne.jpg	3	cmt609lxj002k22pmpgmty1jy	2026-08-23 16:15:24.958	2026-08-23 16:15:24.958	\N	\N	\N
cmt60di5b002t22pmerkuv06o	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787501724090-3.Eden-Exterieur.jpg	uploads/1787501724090-3.Eden-Exterieur.jpg	2	cmt609lxj002k22pmpgmty1jy	2026-08-23 16:15:24.959	2026-08-23 16:15:24.959	\N	\N	\N
cmt60di7o002u22pmkwmfdlp2	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787501724096-14.Eden-La-sc-ne-et-rideau.jpg	uploads/1787501724096-14.Eden-La-sc-ne-et-rideau.jpg	13	cmt609lxj002k22pmpgmty1jy	2026-08-23 16:15:25.044	2026-08-23 16:15:25.044	\N	\N	\N
cmt60di7q002v22pmaq81cek4	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787501724095-13.Eden-la-salle-avant-les-travaux.jpg	uploads/1787501724095-13.Eden-la-salle-avant-les-travaux.jpg	12	cmt609lxj002k22pmpgmty1jy	2026-08-23 16:15:25.046	2026-08-23 16:15:25.046	\N	\N	\N
cmt60di7w002w22pmhhodtyqk	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787501724094-10.Autoportrait-sur-sc-ne.jpg	uploads/1787501724094-10.Autoportrait-sur-sc-ne.jpg	9	cmt609lxj002k22pmpgmty1jy	2026-08-23 16:15:25.052	2026-08-23 16:15:25.052	\N	\N	\N
cmt60di8m002x22pmuvl59tfi	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787501724097-17.Expo---Paris-Gallerie-des-nouvelles-images.jpg	uploads/1787501724097-17.Expo---Paris-Gallerie-des-nouvelles-images.jpg	16	cmt609lxj002k22pmpgmty1jy	2026-08-23 16:15:25.078	2026-08-23 16:15:25.078	\N	\N	\N
cmt60di92002y22pmi3s0numf	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787501724094-12.La-salle-de-l-Eden-.jpg	uploads/1787501724094-12.La-salle-de-l-Eden-.jpg	11	cmt609lxj002k22pmpgmty1jy	2026-08-23 16:15:25.094	2026-08-23 16:15:25.094	\N	\N	\N
cmt60dia9002z22pmgjn7bu2f	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787501724093-7.Cabine-de-projection.jpg	uploads/1787501724093-7.Cabine-de-projection.jpg	6	cmt609lxj002k22pmpgmty1jy	2026-08-23 16:15:25.137	2026-08-23 16:15:25.137	\N	\N	\N
cmt60diah003022pmzt7bb77r	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787501724097-15.L-Eden.Renov--en-2013.jpg	uploads/1787501724097-15.L-Eden.Renov--en-2013.jpg	14	cmt609lxj002k22pmpgmty1jy	2026-08-23 16:15:25.145	2026-08-23 16:15:25.145	\N	\N	\N
cmt60dibq003122pmy49qx920	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787501724097-16.-Exposition-des-photos-de-l-Eden-Gare-St-Charles-.jpg	uploads/1787501724097-16.-Exposition-des-photos-de-l-Eden-Gare-St-Charles-.jpg	15	cmt609lxj002k22pmpgmty1jy	2026-08-23 16:15:25.19	2026-08-23 16:15:25.19	\N	\N	\N
cmt8lx4fg002f22llubfp1cct	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787658840126-Le-voyage-m-diterran-en--15.jpg	uploads/1787658840126-Le-voyage-m-diterran-en--15.jpg	2	cmt8lu9lb001r22ll1tl78jtv	2026-08-25 11:54:04.588	2026-08-27 08:47:19.645	\N	\N	\N
cmt7i2l83000o22llxdkmdd40	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787591913407-St.-david-005-italie-selection-2000-dpi-jpg-54.jpg	uploads/1787591913407-St.-david-005-italie-selection-2000-dpi-jpg-54.jpg	2	cmt7i1iaq000322lly1wd99fe	2026-08-24 17:18:34.995	2026-08-24 17:27:35.638	\N	\N	\N
cmt8v9hgq002n22llm35k5c7x	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787674535308-cadre-dessin-arles-3.jpg	uploads/1787674535308-cadre-dessin-arles-3.jpg	10	cmt8v8qgb002l22llf0q3b3tx	2026-08-25 16:15:37.898	2026-09-09 22:51:41.726	\N	\N	\N
cmt7i2l26000922llix81plnn	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787591913410-st.-italie--selection-2000dpi-jpg-27-speccolaspeccola-1.jpg	uploads/1787591913410-st.-italie--selection-2000dpi-jpg-27-speccolaspeccola-1.jpg	10	cmt7i1iaq000322lly1wd99fe	2026-08-24 17:18:34.782	2026-08-24 17:27:35.646	\N	\N	\N
cmt7i2l20000822llgn9e86o6	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787591913340-0010-florence-2000.jpg	uploads/1787591913340-0010-florence-2000.jpg	11	cmt7i1iaq000322lly1wd99fe	2026-08-24 17:18:34.776	2026-08-24 17:27:35.646	\N	\N	\N
cmt8v9hnf002v22llbu93t19l	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787674535309-Cadre--charpe-.jpg	uploads/1787674535309-Cadre--charpe-.jpg	4	cmt8v8qgb002l22llf0q3b3tx	2026-08-25 16:15:38.139	2026-09-09 22:51:41.715	\N	\N	\N
cmtts2ywm008j22ll88o6bcv7	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788938984419-La-Magalonr.jxl	uploads/1788938984419-La-Magalonr.jxl	3	cmttryl6q008f22llf3beyozg	2026-09-09 07:29:44.759	2026-09-10 22:30:46.281	\N	\N	\N
cmt8ds7cj001c22llz8cplnop	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787645176700-Le-voyage-m-diterran-en--4.jpg	uploads/1787645176700-Le-voyage-m-diterran-en--4.jpg	4	cmt8drvac001222llau5y0lwi	2026-08-25 08:06:18.163	2026-08-25 20:24:05.714	\N	\N	\N
cmt8lx44q002122llun82wj0l	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787658840135-Poteauygraphies--6.jpg	uploads/1787658840135-Poteauygraphies--6.jpg	8	cmt8lu9lb001r22ll1tl78jtv	2026-08-25 11:54:04.202	2026-08-27 08:47:19.65	\N	\N	\N
cmtaq8d9b003p22llmxco2jj2	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787787017164-PA.Ingres-Picasso.-.jpg	uploads/1787787017164-PA.Ingres-Picasso.-.jpg	16	cmtaq6dvr003b22ll1sv8lyww	2026-08-26 23:30:20.063	2026-08-26 23:56:14.446	\N	\N	\N
cmtaq8dje003s22llcenblojj	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787787017289-Tondo-Pharo-2.jpg	uploads/1787787017289-Tondo-Pharo-2.jpg	15	cmtaq6dvr003b22ll1sv8lyww	2026-08-26 23:30:20.426	2026-08-26 23:56:14.446	\N	\N	\N
cmtaq8d28003i22lltrsq1sjn	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787787017158-PA-Le-radeau-de-la-M-duse.jpg	uploads/1787787017158-PA-Le-radeau-de-la-M-duse.jpg	3	cmtaq6dvr003b22ll1sv8lyww	2026-08-26 23:30:19.808	2026-08-26 23:56:14.444	\N	\N	\N
cmtaq8cyb003g22llewbfzl16	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787787017174-PA.La-peste--Michel-Serre..-17.jpg	uploads/1787787017174-PA.La-peste--Michel-Serre..-17.jpg	7	cmtaq6dvr003b22ll1sv8lyww	2026-08-26 23:30:19.668	2026-08-26 23:56:14.445	\N	\N	\N
cmtaq8d4s003l22llwr9lemyu	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787787017184-PA.Les-deux-amies.-Courbet.-.jpg	uploads/1787787017184-PA.Les-deux-amies.-Courbet.-.jpg	9	cmtaq6dvr003b22ll1sv8lyww	2026-08-26 23:30:19.9	2026-08-26 23:56:14.445	\N	\N	\N
cmtcvqhyw004122ll2zoxovt5	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787917194380-Paris-plage-2.jpg	uploads/1787917194380-Paris-plage-2.jpg	1	cmtcuvrx1003u22llyhx5c2ol	2026-08-28 11:39:56.408	2026-09-09 20:27:37.912	\N	\N	\N
cmtcvqi3c004322lll736eja4	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787917194371-Abbaye-01--copie.jpg	uploads/1787917194371-Abbaye-01--copie.jpg	10	cmtcuvrx1003u22llyhx5c2ol	2026-08-28 11:39:56.568	2026-09-09 20:27:37.922	\N	\N	\N
cmtcvqipj004a22ll4aa4s3pb	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787917194369-34-Marseille-.jpg	uploads/1787917194369-34-Marseille-.jpg	4	cmtcuvrx1003u22llyhx5c2ol	2026-08-28 11:39:57.367	2026-09-09 20:27:37.915	\N	\N	\N
cmtcvqhyf004022llhfmd4scp	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787917194374-Faux-semblant-Beaune-7572-copie.jpg	uploads/1787917194374-Faux-semblant-Beaune-7572-copie.jpg	11	cmtcuvrx1003u22llyhx5c2ol	2026-08-28 11:39:56.391	2026-09-09 20:27:37.922	\N	\N	\N
cmtcvqhwy003w22lljy945x2f	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787917194376-ok62Elancourt.jpg	uploads/1787917194376-ok62Elancourt.jpg	12	cmtcuvrx1003u22llyhx5c2ol	2026-08-28 11:39:56.338	2026-09-09 20:27:37.922	\N	\N	\N
cmtcvqimf004922ll40nwkqlt	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787917194370-48-Les-2-Alpes-.jpg	uploads/1787917194370-48-Les-2-Alpes-.jpg	17	cmtcuvrx1003u22llyhx5c2ol	2026-08-28 11:39:57.255	2026-09-09 20:27:37.925	\N	\N	\N
cmtaq8d9w003q22lllh6szszq	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787787017279-parapluie-caillebotte-site-07.jpg	uploads/1787787017279-parapluie-caillebotte-site-07.jpg	0	cmtaq6dvr003b22ll1sv8lyww	2026-08-26 23:30:20.084	2026-08-26 23:56:14.441	\N	\N	\N
cmtaq8d8a003o22llkz67xsyk	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787787017133-botero-8016.jpg	uploads/1787787017133-botero-8016.jpg	11	cmtaq6dvr003b22ll1sv8lyww	2026-08-26 23:30:20.026	2026-08-26 23:56:14.445	\N	\N	\N
cmtaqawtc003t22ll4lu71x8a	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787787138283-PA.Palais-Longchamps-Filig.jpg	uploads/1787787138283-PA.Palais-Longchamps-Filig.jpg	12	cmtaq6dvr003b22ll1sv8lyww	2026-08-26 23:32:18.72	2026-08-26 23:56:14.446	\N	\N	\N
cmtcvqi70004422llg1tllc1i	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787917194367-014--IMP-Cannes-Faux-semblant-2_MG_2493.jpg	uploads/1787917194367-014--IMP-Cannes-Faux-semblant-2_MG_2493.jpg	6	cmtcuvrx1003u22llyhx5c2ol	2026-08-28 11:39:56.7	2026-09-09 20:27:37.92	\N	\N	\N
cmtcvqhx8003x22llhmwtqyux	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787917194374-Ikea-trompe-l-oeil-2179.jpg	uploads/1787917194374-Ikea-trompe-l-oeil-2179.jpg	7	cmtcuvrx1003u22llyhx5c2ol	2026-08-28 11:39:56.348	2026-09-09 20:27:37.92	\N	\N	\N
cmtcvqig4004622llguw5m3qg	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787917194367-2-alpes-Faux-semblants-.-C.Ramade-97-08-27-.jpg	uploads/1787917194367-2-alpes-Faux-semblants-.-C.Ramade-97-08-27-.jpg	8	cmtcuvrx1003u22llyhx5c2ol	2026-08-28 11:39:57.029	2026-09-09 20:27:37.921	\N	\N	\N
cmtts35v3008k22lldheaefb8	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788938993325-Prado-immobilier.jxl	uploads/1788938993325-Prado-immobilier.jxl	4	cmttryl6q008f22llf3beyozg	2026-09-09 07:29:53.775	2026-09-10 22:30:46.281	\N	\N	\N
cmtefwuoy004t22llgu7z796x	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788011549941--mus-um-cadre-.jpg	uploads/1788011549941--mus-um-cadre-.jpg	3	cmtefwkh3004h22llaqss7tuf	2026-08-29 13:52:31.33	2026-09-03 09:41:27.789	\N	\N	\N
cmtefwusp004x22ll3ye8zagx	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788011549948-Oiseau-vitines-Magritte.jpg	uploads/1788011549948-Oiseau-vitines-Magritte.jpg	10	cmtefwkh3004h22llaqss7tuf	2026-08-29 13:52:31.465	2026-09-03 09:41:27.796	\N	\N	\N
cmtts3ffr008l22llgoo6mywe	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788939005744-L-Oasis.jxl	uploads/1788939005744-L-Oasis.jxl	6	cmttryl6q008f22llf3beyozg	2026-09-09 07:30:06.183	2026-09-10 22:30:46.283	\N	\N	\N
cmtcvqiyz004c22llov3uoysm	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787917194371-Faux-semblant-BD_MG_8812.jpg	uploads/1787917194371-Faux-semblant-BD_MG_8812.jpg	9	cmtcuvrx1003u22llyhx5c2ol	2026-08-28 11:39:57.707	2026-09-09 20:27:37.922	\N	\N	\N
cmtcvqhxv003z22ll4wn1c5dv	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787917194376-Le-lac-de-C-me-2000.jpg	uploads/1787917194376-Le-lac-de-C-me-2000.jpg	3	cmtcuvrx1003u22llyhx5c2ol	2026-08-28 11:39:56.371	2026-09-09 20:27:37.915	\N	\N	\N
cmtcvqksx004d22ll6caad0yf	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787917194369-28-St-Gervais-.jpg	uploads/1787917194369-28-St-Gervais-.jpg	5	cmtcuvrx1003u22llyhx5c2ol	2026-08-28 11:40:00.081	2026-09-09 20:27:37.919	\N	\N	\N
cmtcvqiha004722lltyr1lx47	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787917194368-018.La-Ciotat.tif	uploads/1787917194368-018.La-Ciotat.tif	2	cmtcuvrx1003u22llyhx5c2ol	2026-08-28 11:39:57.07	2026-09-09 20:27:37.912	\N	\N	\N
cmtcw9muz004g22lljghsi6rg	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787918088476-01-La-vague-cintra--1-sur-1--copie.jpg	uploads/1787918088476-01-La-vague-cintra--1-sur-1--copie.jpg	0	cmtcuvrx1003u22llyhx5c2ol	2026-08-28 11:54:49.211	2026-09-09 20:27:37.91	\N	\N	\N
cmtcvqihq004822lll7qpauue	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787917194382-table-orientation-ndg--copie.jpg	uploads/1787917194382-table-orientation-ndg--copie.jpg	15	cmtcuvrx1003u22llyhx5c2ol	2026-08-28 11:39:57.086	2026-09-09 20:27:37.924	\N	\N	\N
cmtefwupo004u22ll3azqglql	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788011549951-Salle-de-Provence-03-.jpg	uploads/1788011549951-Salle-de-Provence-03-.jpg	0	cmtefwkh3004h22llaqss7tuf	2026-08-29 13:52:31.357	2026-09-03 09:41:27.784	\N	\N	\N
cmtefwuj1004k22ll54lhgcfg	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788011549948-Mouton-2.jpg	uploads/1788011549948-Mouton-2.jpg	16	cmtefwkh3004h22llaqss7tuf	2026-08-29 13:52:31.117	2026-09-03 09:41:27.799	\N	\N	\N
cmtefwuqu004w22llw0l8n78z	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788011549949-reserve-girafe-2.jpg	uploads/1788011549949-reserve-girafe-2.jpg	17	cmtefwkh3004h22llaqss7tuf	2026-08-29 13:52:31.398	2026-09-03 09:41:27.799	\N	\N	\N
cmtcvqi1z004222lll0xz4w8k	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787917194377-Orly-fer---repasser--1-sur-1-.jpg	uploads/1787917194377-Orly-fer---repasser--1-sur-1-.jpg	13	cmtcuvrx1003u22llyhx5c2ol	2026-08-28 11:39:56.519	2026-09-09 20:27:37.924	\N	\N	\N
cmtcvqhxq003y22llfuvhtz3l	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787917194381-table-orientation-galibier--copie.jpg	uploads/1787917194381-table-orientation-galibier--copie.jpg	14	cmtcuvrx1003u22llyhx5c2ol	2026-08-28 11:39:56.366	2026-09-09 20:27:37.924	\N	\N	\N
cmtcvse3v004f22lls0umpo6d	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787917284147-table-orientation-deux-alpes-.jpg	uploads/1787917284147-table-orientation-deux-alpes-.jpg	16	cmtcuvrx1003u22llyhx5c2ol	2026-08-28 11:41:24.715	2026-09-09 20:27:37.925	\N	\N	\N
cmtcvqi7b004522lljuh9zlu5	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787917194380-parapluie-caillebotte-site-07-copie.jpg	uploads/1787917194380-parapluie-caillebotte-site-07-copie.jpg	18	cmtcuvrx1003u22llyhx5c2ol	2026-08-28 11:39:56.711	2026-09-09 20:27:37.925	\N	\N	\N
cmtefwulp004p22ll2o9gx5cm	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788011549942-Coelacante-anciennnes-r-serves.jpg	uploads/1788011549942-Coelacante-anciennnes-r-serves.jpg	4	cmtefwkh3004h22llaqss7tuf	2026-08-29 13:52:31.213	2026-09-03 09:41:27.79	\N	\N	\N
cmtefwukd004m22llf6ovls1p	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788011549944-Elephant-d-Asie.jpg	uploads/1788011549944-Elephant-d-Asie.jpg	6	cmtefwkh3004h22llaqss7tuf	2026-08-29 13:52:31.165	2026-09-03 09:41:27.791	\N	\N	\N
cmtefwuq5004v22ll7cw7wfwn	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788011549951-Salle-de-Provence-02-04258.jpg	uploads/1788011549951-Salle-de-Provence-02-04258.jpg	1	cmtefwkh3004h22llaqss7tuf	2026-08-29 13:52:31.373	2026-09-03 09:41:27.787	\N	\N	\N
cmtts46wr008m22lltgqk8evr	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788939041189-Marseille-2014.jpg	uploads/1788939041189-Marseille-2014.jpg	7	cmttryl6q008f22llf3beyozg	2026-09-09 07:30:41.787	2026-09-10 22:30:46.285	\N	\N	\N
cmtefwujn004l22ll9kwrrm1d	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788011549944-Elephant-mus-um-3341.jpg	uploads/1788011549944-Elephant-mus-um-3341.jpg	7	cmtefwkh3004h22llaqss7tuf	2026-08-29 13:52:31.14	2026-09-03 09:41:27.794	\N	\N	\N
cmtefwumk004s22ll7amc9kcd	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788011549951-Salle-de-Provence-03-05354.jpg	uploads/1788011549951-Salle-de-Provence-03-05354.jpg	2	cmtefwkh3004h22llaqss7tuf	2026-08-29 13:52:31.244	2026-09-03 09:41:27.788	\N	\N	\N
cmtefwv4d004z22ll75scev6x	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788011549948-oiseaux-vitrines-mus-um-.jpg	uploads/1788011549948-oiseaux-vitrines-mus-um-.jpg	9	cmtefwkh3004h22llaqss7tuf	2026-08-29 13:52:31.886	2026-09-03 09:41:27.795	\N	\N	\N
cmtefwux0004y22llnv0gwpzn	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788011549943-dinausure-lavabo-bon-.jpg	uploads/1788011549943-dinausure-lavabo-bon-.jpg	5	cmtefwkh3004h22llaqss7tuf	2026-08-29 13:52:31.62	2026-09-03 09:41:27.791	\N	\N	\N
cmtefwugc004i22llry063djy	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788011549952-YE-aye.jpg	uploads/1788011549952-YE-aye.jpg	8	cmtefwkh3004h22llaqss7tuf	2026-08-29 13:52:31.02	2026-09-03 09:41:27.795	\N	\N	\N
cmtefwuic004j22ll2d7fzla9	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788011549945-flamand-cabine-telephonique-01-2.jpg	uploads/1788011549945-flamand-cabine-telephonique-01-2.jpg	11	cmtefwkh3004h22llaqss7tuf	2026-08-29 13:52:31.092	2026-09-03 09:41:27.797	\N	\N	\N
cmtefwul0004n22ll33wi62f9	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788011549951-Thylacine-.jpg	uploads/1788011549951-Thylacine-.jpg	13	cmtefwkh3004h22llaqss7tuf	2026-08-29 13:52:31.188	2026-09-03 09:41:27.797	\N	\N	\N
cmtefwul3004o22ll6y93ctd4	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788011549949-panth-re-vitrines-rouges.jpg	uploads/1788011549949-panth-re-vitrines-rouges.jpg	12	cmtefwkh3004h22llaqss7tuf	2026-08-29 13:52:31.191	2026-09-03 09:41:27.797	\N	\N	\N
cmtefwumh004r22lligr3txwv	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788011549947-gazelles-r-serves-mus-um-.jpg	uploads/1788011549947-gazelles-r-serves-mus-um-.jpg	15	cmtefwkh3004h22llaqss7tuf	2026-08-29 13:52:31.241	2026-09-03 09:41:27.799	\N	\N	\N
cmtefwuma004q22lllgbuygom	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788011549947-hydroc-phale-2024.jpg	uploads/1788011549947-hydroc-phale-2024.jpg	19	cmtefwkh3004h22llaqss7tuf	2026-08-29 13:52:31.234	2026-09-03 09:41:27.803	\N	\N	\N
cmtts4byj008n22llfmw17hal	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788939047901-Marseille-2-2.jpg	uploads/1788939047901-Marseille-2-2.jpg	12	cmttryl6q008f22llf3beyozg	2026-09-09 07:30:48.333	2026-09-10 22:30:46.287	\N	\N	\N
cmtts4jiz008o22lls6e7ppcz	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788939057669-Marseille-site-trait-es--5.jpg	uploads/1788939057669-Marseille-site-trait-es--5.jpg	8	cmttryl6q008f22llf3beyozg	2026-09-09 07:30:58.139	2026-09-10 22:30:46.285	\N	\N	\N
cmtkjnzzm007n22llm5vozyvb	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788380652512-Papy-bitte-vx-port-2.jpg	uploads/1788380652512-Papy-bitte-vx-port-2.jpg	1	cmthvob3v005j22llw2pmotim	2026-09-02 20:24:13.81	2026-09-09 20:05:58.224	\N	\N	\N
cmtkjo01n007t22llwr8101y4	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788380652519-Table-orientation-NDG-2.jpg	uploads/1788380652519-Table-orientation-NDG-2.jpg	12	cmthvob3v005j22llw2pmotim	2026-09-02 20:24:13.883	2026-09-09 20:05:58.233	\N	\N	\N
cmtkjnzz4007m22ll9c4uute7	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788380652512-Mont-e-de-la-batterie-.jpg	uploads/1788380652512-Mont-e-de-la-batterie-.jpg	13	cmthvob3v005j22llw2pmotim	2026-09-02 20:24:13.792	2026-09-09 20:05:58.233	\N	\N	\N
cmtkjo03h007w22llpivckf8d	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788380652519-Travaux-Marseille-2013-3.jpg	uploads/1788380652519-Travaux-Marseille-2013-3.jpg	4	cmthvob3v005j22llw2pmotim	2026-09-02 20:24:13.949	2026-09-09 20:05:58.227	\N	\N	\N
cmtkjo028007v22llunq1lmp4	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788380652515-Plage-Borelly-3.jpg	uploads/1788380652515-Plage-Borelly-3.jpg	14	cmthvob3v005j22llw2pmotim	2026-09-02 20:24:13.904	2026-09-09 20:05:58.233	\N	\N	\N
cmtkjnzw0007k22llufrlicga	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788380652509-K-k--corniche-scooter-3.jpg	uploads/1788380652509-K-k--corniche-scooter-3.jpg	8	cmthvob3v005j22llw2pmotim	2026-09-02 20:24:13.68	2026-09-09 20:05:58.229	\N	\N	\N
cmtkjnzt9007f22ll1tilzubw	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788380652506-003-poteau-La-route-des-goudes-3.jpg	uploads/1788380652506-003-poteau-La-route-des-goudes-3.jpg	26	cmthvob3v005j22llw2pmotim	2026-09-02 20:24:13.581	2026-09-09 20:05:58.235	\N	\N	\N
cmtkjo06f007x22ll0yyda08w	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788380652516-Pont-de-la-fausse-monnaie-.jpg	uploads/1788380652516-Pont-de-la-fausse-monnaie-.jpg	16	cmthvob3v005j22llw2pmotim	2026-09-02 20:24:14.055	2026-09-09 20:05:58.234	\N	\N	\N
cmtkjnztq007h22llpb91patv	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788380652508-15092004-004-marseille-pilotage-frioul--.jpg	uploads/1788380652508-15092004-004-marseille-pilotage-frioul--.jpg	21	cmthvob3v005j22llw2pmotim	2026-09-02 20:24:13.598	2026-09-09 20:05:58.235	\N	\N	\N
cmtts5hlp008r22llhi1pkbco	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788939101951-Cantini.jxl	uploads/1788939101951-Cantini.jxl	11	cmttryl6q008f22llf3beyozg	2026-09-09 07:31:42.301	2026-09-10 22:30:46.287	\N	\N	\N
cmtts5d3s008q22llj8c2pfm7	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788939096156-01-07-2015-angle-rue-la-plaine.jxl	uploads/1788939096156-01-07-2015-angle-rue-la-plaine.jxl	9	cmttryl6q008f22llf3beyozg	2026-09-09 07:31:36.472	2026-09-10 22:30:46.286	\N	\N	\N
cmtkjnzth007g22lly5j19gav	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788380652519-Sur-la-corniche---Marseille.jpg	uploads/1788380652519-Sur-la-corniche---Marseille.jpg	6	cmthvob3v005j22llw2pmotim	2026-09-02 20:24:13.589	2026-09-09 20:05:58.228	\N	\N	\N
cmtkjo019007s22ll1ntt42rb	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788380652517-Poteau-chaussures-rouges-.jpg	uploads/1788380652517-Poteau-chaussures-rouges-.jpg	22	cmthvob3v005j22llw2pmotim	2026-09-02 20:24:13.869	2026-09-09 20:05:58.235	\N	\N	\N
cmtkjo08y007y22llh0f1fzjj	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788380652517-Route-des-goudes-04-.jpg	uploads/1788380652517-Route-des-goudes-04-.jpg	24	cmthvob3v005j22llw2pmotim	2026-09-02 20:24:14.146	2026-09-09 20:05:58.235	\N	\N	\N
cmtts6g4u008t22llbr8i25ea	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788939146590-Cours-julien.jxl	uploads/1788939146590-Cours-julien.jxl	13	cmttryl6q008f22llf3beyozg	2026-09-09 07:32:27.054	2026-09-10 22:30:46.287	\N	\N	\N
cmtkjo00c007p22ll6qqbpz21	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788380652521-Vieux-port-nuit-.jpg	uploads/1788380652521-Vieux-port-nuit-.jpg	0	cmthvob3v005j22llw2pmotim	2026-09-02 20:24:13.836	2026-09-09 20:05:58.223	\N	\N	\N
cmtts73x2008u22ll79pu26zk	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788939177415-CMA-CGM.jxl	uploads/1788939177415-CMA-CGM.jxl	14	cmttryl6q008f22llf3beyozg	2026-09-09 07:32:57.878	2026-09-10 22:30:46.287	\N	\N	\N
cmtkjnztu007i22llu5y4dcyc	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788380652522-Zidane.jpg	uploads/1788380652522-Zidane.jpg	11	cmthvob3v005j22llw2pmotim	2026-09-02 20:24:13.602	2026-09-09 20:05:58.233	\N	\N	\N
cmtujm5f7008v22llfu17pa9x	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788985228379-Co-Ancien-quartier--22arabe-22--22Chez-Moulet-22-1988-.jpg	uploads/1788985228379-Co-Ancien-quartier--22arabe-22--22Chez-Moulet-22-1988-.jpg	10	cmttryl6q008f22llf3beyozg	2026-09-09 20:20:29.299	2026-09-10 22:30:46.287	\N	\N	\N
cmtkjnzzy007o22ll9iagr95g	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788380652509-Les-flots-bleus-.jpg	uploads/1788380652509-Les-flots-bleus-.jpg	9	cmthvob3v005j22llw2pmotim	2026-09-02 20:24:13.822	2026-09-09 20:05:58.23	\N	\N	\N
cmtkjnzu1007j22llwdqzi7gg	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788380652507-006-VTT-1.jpg	uploads/1788380652507-006-VTT-1.jpg	3	cmthvob3v005j22llw2pmotim	2026-09-02 20:24:13.609	2026-09-09 20:05:58.225	\N	\N	\N
cmtkjo0il008222lltf8kw540	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788380652518-Rouvi-re-8581.jpg	uploads/1788380652518-Rouvi-re-8581.jpg	15	cmthvob3v005j22llw2pmotim	2026-09-02 20:24:14.493	2026-09-09 20:05:58.234	\N	\N	\N
cmtkjo016007r22lljgizmmir	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788380652508-Chien-endoume-.jpg	uploads/1788380652508-Chien-endoume-.jpg	7	cmthvob3v005j22llw2pmotim	2026-09-02 20:24:13.866	2026-09-09 20:05:58.229	\N	\N	\N
cmtkjo09d007z22ll5xdnjn18	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788380652508-Callelongue-dumon-01-.jpg	uploads/1788380652508-Callelongue-dumon-01-.jpg	23	cmthvob3v005j22llw2pmotim	2026-09-02 20:24:14.161	2026-09-09 20:05:58.235	\N	\N	\N
cmtkjo0ca008022llklqj97qa	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788380652513-Passe-nord-marseille-2.jpg	uploads/1788380652513-Passe-nord-marseille-2.jpg	27	cmthvob3v005j22llw2pmotim	2026-09-02 20:24:14.266	2026-09-09 20:05:58.235	\N	\N	\N
\.


--
-- Data for Name: profiles; Type: TABLE DATA; Schema: public; Owner: christian
--

COPY public.profiles (id, name, bio, "avatarUrl", "createdAt", "updatedAt", tagline) FROM stdin;
cmt5oow53000022nzmt2pssta	Christian Ramade	Christian Ramade\r\nBiographie\r\nNé en 1947 à Marseille à la clinique Beauregard (un joli nom pour un futur photographe).\r\nIl découvre la photographie dès l’enfance. A douze ans, il réalise son premier reportage en Tunisie, lors d’un voyage avec ses grands-parents, équipé d’un appareil Ultra-Fex 6×9.\r\nEn 1963, il accompagne Jean Suquet — écrivain, poète et photographe, récompensé par le prix Niépce — dans un reportage consacré aux ports de Marseille. La même année il installe un laboratoire noir et blanc dans un réduit de l’appartement familial.\r\nEn 1967 la parution de la revue Photo, de l’édition française de Vogue et, de la revue Zoom, contribue à élargir son regard sur la photographie. Il est  profondément marqué par le film Blow-Up de Michelangelo Antonioni primé cette même année à Cannes. \r\nPour son baccalauréat son père lui offre un Leica M4 équipé d’un objectif de 35 mm. Il découvre les grands photographes américains maitres de la couleur, parmi lesquels William Eggleston, Stephen Shore, Richard Misrach et Joel Meyerowitz. \r\nLa même année, il vend ses premières photographies à un promoteur marseillais ainsi qu’à la socièté Citroën, mais il n'abandonne pas pour autant ses études de médecine. Passionné de moto Il est  engagé comme essayeur et photo reporter par la revue Motocyclisme, puis rejoint en 1971 la revue concurrente Motorama.\r\nIl s’intéressera à la photographie médicale dirigera le service de documentation de la faculté d’odontologie de Marseille. \r\n1975 est une révèlation avec les premières Rencontres de la photographie d’Arles qui fêtent actuellement leurs 50 ans.\r\nSon premier voyage à New York, en 1977, marque un tournant important dans sa démarche, dès ses premiers pas  dans la cité il abandonne ses films noir et blanc pour choisir définitivement la couleur comme moyen d’expression. \r\nDurant les années 1980, il participe à de nombreux stages à Arles auprès de grands maîtres de la photographie couleur, tels que John Batho, Jay Maisel, Franco Fontana, Bruce Davidson et Ingalill Snitt (une ancienne assistante de Guy Bourdin).\r\nEn 1984, il suit un stage avec Luigi Ghirri aux Rencontres internationales de la photographie d’Arles. Cette rencontre constitue pour lui une révélation va définitivement transformer philosophie de l’image photographique.\r\nEn 1985, il obtient une résidence au centre d’art "la Villa Arson" à Nice qui sera suivie d’une exposition. En 1987, il présente l’exposition “Germaine et le Nord Pinus” à la galerie Aréna de l’École nationale de la photographie d’Arles grâce au soutien de son directeur Alain Desvergnes. La même année débute une collaboration de dix ans avec l’UNESCO et les centres culturels français de la Méditerranée.\r\nEn 1988 paraît son premier livre, Marseille vraiment, publié aux éditions JYM et préfacé par l’écrivaine Edmonde Charles-Roux( prix Goncourt). \r\nEn 1990, l’exposition Germaine et le Nord Pinus est présentée aux Rencontres d’Arles.\r\nEn 1991, il se rend à Hambourg, chez Nino Mondhe spécialiste du Dye-transfert pour contrôler 120 tirages 50x60 commandés par la galeriste new-yorkaise Patricia Lowinsky. \r\nLa disparition brutale de Luigi Ghirri, le 14 février 1992 à Roncocesi, le marque profondément. Il commence alors une collaboration de huit ans avec le programme des \r\n« 100 sites historiques de la Méditerranée » de l’UNESCO. Il crée également le festival “Aubagne en vue Méditerranée” qu’il va diriger jusqu’en 2000.\r\nEn 1992 paraît "Escale à Thessalonique", accompagné d’une exposition en Grèce. En 1993, Christian Ramade est invité en résidence au consulat de France à Florence, il y réalise un travail panoramique consacré à la ville, l'exposition est présenté à la fin de l’année.\r\nEn 1994, Paola Ghirri lui prête une exposition consacrée à l’œuvre de Luigi Ghirri pour la deuxième édition du festival d’Aubagne, en hommage au photographe disparu. La même année, il rencontre Olivo Barbieri. En 1996, Willy Ronis accepte de devenir le parrain de son festival d’Aubagne. En 1997, Christian Ramade dirige aux Rencontres d’Arles un stage intitulé “Des couleurs dans la nuit”.\r\nEn 2002, il crée et dirige, avec Joëlle Gardes, professeure à la Sorbonne, la collection  "Texte avec vue" aux éditions "Images en manœuvres". Dix ouvrages seront publiés dans cette collection entre 2002 et 2008. La même année paraît "Marseille chemins d’intimité", publié chez Équinoxes, suivi de deux expositions à Paris, au "Train Bleu",(gare de Lyon) et au "Forum des Halles".\r\nDe 2004 à 2015, il collabore régulièrement avec la revue "Réponses Photo", pour laquelle il écrit des articles de fond et tient une tribune régulière. En 2006, il dirige le studio de mode du site en ligne "Monshowroom;com".\r\nEn 2008, le cabinet d’architecture marseillais Fatosme-Lefèvre, chargé de la rénovation de l’hôtel Concorde Palm Beach, lui confie la décoration des 182 chambres. Cette commande représente l’acquisition de 550 photographies. La même année, après deux années de démarches, il obtient l’autorisation de photographier les 21 chapelles du Sacro Monte d’Orta, inscrites au patrimoine mondial de l’UNESCO. Sponsorisé par le Mécène Pierre Dumon Il consacrera  une année à photographier les quelque 1 000 statues en terre cuite grandeur nature qui peuplent ce site exceptionnel. Un livre consacré au Sacro Monte d’Orta paraît en 2010. En 2011, une exposition monumentale de ces photographies est présentée au "Museo Regionale di Scienze Naturali di Torino".\r\nEn 2016, Christian Ramade crée à Aubagne la biennale photographique Photologies avec Gilbert Garcin en invité d'honneur ( Gilbert Garcin avait commencé la photographie en 1994 lors d’un stage animé par Christian Ramade avant d’acquérir une renommée internationale). En 2018, la deuxième édition de Photologies est consacrée à plusieurs grands photographes italiens : Gianni Berengo Gardin, Franco Fontana, Mario Giacomelli, Paolo Gioli, Luigi Ghirri et Paolo Ventura.\r\nEn 2020 paraît le livre “Ceci n’est pas une carte postale" accompagné d’une exposition à la galerie Parisienne "La Nouvelle Chambre Claire". \r\nEn 2021, il publie Photo-Roman, son quinzième ouvrage et son premier livre autobiographique, aux éditions Photo#graphie. \r\nSon seizième livre “Poteaugraphies” paraît en 2022.\r\nEn 2024, Christian Ramade fait donation de son travail consacré au cinéma L’Eden.\r\n\r\nSes œuvres furent présentées dans de nombreuses expositions en France et à l’étranger, notamment à Paris, Marseille, Arles, Aix-en-Provence, Turin, Milan, Brescia, Hambourg, New-York,  Florence, Tunis, Thessalonique, Alger, Valencia...\r\nSes photographies sont conservées dans plusieurs collections publiques et privées, parmi lesquelles la Bibliothèque nationale de France, l’École nationale supérieure de la photographie d’Arles, la Fondation Regards de Provence à Marseille, la faculté de Parme, l’Institut français de Florence et l’Institute of Photography Museum of Art de Chula Vista, en Californie.\r\nIl travaille actuellement sur un grand projet concernant le palais Longchamps et le Muséum d’histoire naturelle de Marseille.	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787503295322-18.La-Ste-Victoire-.jpg	2026-08-23 10:48:20.919	2026-08-31 12:35:33.727	Regarder l'invisible
\.


--
-- Data for Name: series; Type: TABLE DATA; Schema: public; Owner: christian
--

COPY public.series (id, name, slug, "coverUrl", "order", "createdAt", "updatedAt", description, "shootDate", tags, visibility, "shootDateLabel", "referenceUrl", "linkedTicketId", featured) FROM stdin;
cmt5u9wg3000222pms8nvr7ig	La conquête de l'espace	la-conquete-de-lespace	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787492213133-Marseille-Prado.jpg	13	2026-08-23 13:24:39.171	2026-09-10 21:59:05.003	Comment reconquerir la troisième dimenssion perdue lors de l'empreine photographique.\r\n\r\n\r\nLe De Pictura, écrit par Leon Battista Alberti en 1435, est un traité de peinture qui expose pour la première fois les principes de la perspective linéaire et du point de fuite. Il y considère le tableau comme une fenêtre ouverte sur un monde, qu’il s’agit de représenter de la manière la plus fidèle possible.\r\n Six cents ans plus tard la photographie va capturer l’empreinte lumineuse du réel (du vu) d’un espace tridimensionnel pour la fixer sur une pellicule ou un capteur qui sont des surfaces planes à deux dimensions (hauteur, largeur), dans cet acte on va donc perdre irrémédiablement  la profondeur. C’est au savoir faire du photographe de reconquérir la vision de l’espace et de la profondeur. Pour cela il va s’aider du point de fuite, de l’interaction des couleurs entre elles, de l’utilisation des images mises en abîme dans l’image, des repoussoirs…(cf: Les tableaux de Vermer et la photographie du photographe de Fès).	\N	{}	public	\N	\N	\N	f
cmt5ux60t000f22pmb6l0ko8q	Germaine et le Nord Pinus	germaine-et-le-nord-pinus	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787492564049-002-Germaine--jpg.jpg	12	2026-08-23 13:42:44.669	2026-09-10 21:59:05.003	Arles, juillet 1986, les RIP sont  en effervescence. Le directeur de l’Ecole Nationale de la Photographie Alain Desvergnes me propose de réaliser un reportage sur l’ancien hôtel Nord-Pinus, en échange d’une exposition à la Galerie Aréna. L’hôtel, fermé depuis quatre ans, abrite encore son ancienne propriétaire Mme Bessière âgée de 85 ans, plus connue sous son nom d’artiste de Germaine Gilbert; elle y vit en recluse avec ses chats et son chien Warum.\r\n      En septembre je décide d’investir les lieux. Je m’équipe de deux boitiers, un solide trépied, quelques boites de chocolats pour germaine et surtout des douilles et un sac rempli d’ampoules de toutes sortes afin de retrouver l’ambiance et l’éclairage original du lieu. \r\n     Trois jours intensifs hors du temps, dans le labyrinthe des corridors et des chambres, en une marche aléatoire ou chaque image sera un haïku en couleur. Quelques jours plus tard, je présente les images au directeur de l’ENP qui est emballé mais qui me réclame « l’indispensable » portrait de Germaine. J’ai beau lui dire que je ne suis pas un entomologiste, il reste intraitable. Je retourne à l’hôtel une dernière fois; une photo noir et blanc de Germaine, posée sur un meuble prise il y a 50 ans, vient à mon secours, mettant la vraie Germaine en abîme. Le 15 janvier 1987 le vernissage à la galerie Arèna a lieu en présence de Germaine qui lève sa coupe de champagne en criant:: « j’ai 20 ans » !	\N	{}	public	\N	\N	\N	f
cmtcuvrx1003u22llyhx5c2ol	Les faux-semblants	les-faux-semblants	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787918088476-01-La-vague-cintra--1-sur-1--copie.jpg	3	2026-08-28 11:16:02.965	2026-09-10 21:59:04.994	Les espaces urbains sont de véritables décors de théâtre. Une fois repéré la bonne affiche, le bon mur peint je cherche le bon cadrage et je n’ai  plus qu’à attendre les acteurs, ces passants involontaires qui immortalisés par l’instantané nous rendront inséparable le vrai du faux, le réel de l'ambiguîté de la photographie.	\N	{}	public	\N	\N	\N	f
cmt8lu9lb001r22ll1tl78jtv	Poteaugraphie	poteaugraphie	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787658840201-Poteauygraphies-36.jpg	7	2026-08-25 11:51:51.311	2026-09-10 21:59:04.998	On ne photographie pas un poteau. Les poteaux en général on les évites, ils gênent, donc on les sort du cadre, mais la photographie m’as permis de transgresser cette règle avec allégresse.	\N	{}	public	\N	\N	\N	f
cmttryl6q008f22llf3beyozg	Marseille aux volets clos	marseille-aux-volets-clos	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788938902825-Valmante.jxl	1	2026-09-09 07:26:20.354	2026-09-10 22:30:47.447	Marseille n'est pas une ville qui se pâme ou qui s'offre. Elle se tient raide le long de ses rues.  Elle se dresse sans coquetterie dans un site magnifique et l'une de ses contradiction réside dans la fascination qu'éprouve pour la mer Marseille-ville ouverte et ce refus qu'affiche l'autre ville, Marseille-aux-volets-clos, celle qui lui tourne le dos. (Extrait de la Préface d'Edmonde Charles-Roux, livre "Marseille Vraiment" de Christian Ramade).	\N	{}	public	\N	\N	\N	f
cmt8vvwh4003222ll1xuw3fqh	New-York	new-york	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787675625407-New-york-no-parking-2.jpg	5	2026-08-25 16:33:03.784	2026-09-10 21:59:04.996	\N	\N	{}	public	\N	\N	\N	f
cmtefwkh3004h22llaqss7tuf	Muséum	museum	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788011537574-Elephant-d-Asie.jpg	2	2026-08-29 13:52:18.088	2026-09-10 21:59:04.993	Le Palais Longchamp abrite depuis 1869. Labellisé Musée de France en 2002 il est reconnu comme un "musée scientifique majeur" et la biodiversité est au coeur de ses préoccupations. J'y ai réalisée une grande exposition en 1987 "au muséum d'histoire surnaturelle"  et je prépare actuellement une grande rétrospective pour l'année 2027.	\N	{}	public	\N	\N	\N	f
cmt8v8qgb002l22llf0q3b3tx	Le cadre	le-cadre	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787674502388-peyrassol-3.jpg	6	2026-08-25 16:15:02.891	2026-09-10 21:59:04.997	LE CADRE\r\n\r\nCadrer c’est l’étape essentielle de l’acte photographique. Cette empreinte est un moment fascinant, mais le choix de ce cadre va implicitement délimiter un hors champs, c’est à dire un non vu, et cela nous amène au paradoxe suivant: la photographie qui est une prise “du vu” (elle se nourrit exclusivement du réel) n’est-elle pas aussi le plus beau des mensonges...	\N	{}	public	\N	\N	\N	f
cmthvob3v005j22llw2pmotim	Marseille sur mer	marseille-sur-mer	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1788380652521-Vieux-port-nuit-.jpg	0	2026-08-31 23:37:05.083	2026-09-10 21:59:04.99	\N	\N	{}	public	\N	\N	\N	f
cmt609lxj002k22pmpgmty1jy	L'Eden	leden	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787502474977-4.Eden-enseigne.jpg	10	2026-08-23 16:12:23.239	2026-09-10 21:59:05.001	L’EDEN, le plus vieux cinéma du monde\r\n\r\nLe 21 mars 1899 dans la salle de spectacle de la ville de La Ciotat l’Eden est projeté  le premier film des frères Lumières. Par la suite cette salle prestigieuse connaitra les débuts des plus grands artistes de l’époque: Fernandel, Yves Montant, Edith Piaf…Puis vient la crise et l’Eden s’endort sous la poussière. \r\n\r\nLes photographies de Christian Ramade vous font découvrir l’ Eden juste avant sa brillante renaissance en 2013 lorsque Marseille fut élue “capitale de la culture”. Depuis 2024 elles appartiennent à l’Eden à la suite d’une donation du photographe Christian Ramade.	2013-01-01 00:00:00	{}	public	2013	\N	\N	f
cmt7i1iaq000322lly1wd99fe	L'italia come la vedo	litalia-come-la-vedo	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787591913325-Fontaine-Tr-vi-Rome-.jpg	9	2026-08-24 17:17:44.547	2026-09-10 21:59:05	L'italia come la vedo	\N	{}	public	\N	\N	\N	f
cmtaq6dvr003b22ll1sv8lyww	La peinture abîmée.	la-peinture-abimee	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787787017279-parapluie-caillebotte-site-07.jpg	4	2026-08-26 23:28:47.559	2026-09-10 21:59:04.995	Lorsque le photographe et l'oeuvre piégent le spectateur alors que la phrase de Duchamp nous dit: "c'est le regardeur qui fait le tableau".	\N	{}	public	\N	\N	\N	f
cmt8drvac001222llau5y0lwi	Le voyage méditerranéen	le-voyage-mediterraneen	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787645161969-Le-voyage-m-diterran-en-1-2.jpg	8	2026-08-25 08:06:02.532	2026-09-10 21:59:04.999	Travail réalisé sur plusieurs années en collaboration étroite avec l'Unesco, Algérie, Espagne, Grèce, Italie, Maroc, Tunisie.	\N	{}	public	\N	\N	\N	f
cmt5vm22w000v22pmd3mmrqe8	Orta	orta	https://christianramade.s3.eu-north-1.amazonaws.com/uploads/1787493879300-06-chapelle-VXIII-2103.jpg	11	2026-08-23 14:02:05.96	2026-09-10 21:59:05.001	Le lac d’Orta est situé dans le Piémont en Italie. Au XIX siècle c’était le lac favori des grands romantiques. Au XVI siècle sur les hauteurs boisées du lac furent édifiées vingt chapelles; un chantier pharaonique qui dura 200 ans. Ces chapelles qui constituent un chemin de dévotion sont décorées de peintures murales et habitées par 800 statues en terre cuite polychrome grandeur nature d’un réalisme saisissant. Les chapelles ne sont pas électrifiées et des grilles et claustras en interdisant l’accès le public ne peut admirer ces merveilles qu’à distance depuis le porche d’entrée. Ces sanctuaires illustrent des épisodes de la vie de Saint François d’Assise. Le sacro monte est inscrit depuis 2003 au patrimoine mondial de l’unesco. Il a fallu un an à Christian Ramade pour obtenir les autorisations de pénétrer dans les 21 chapelles et photographier les statues. Ce travail s’est étalé sur une année. Cette exposition fut présentée en 2010 au Palais des arts à Marseille puis en octobre 2011 au Palais des sciences de la ville de Turin.\r\nCe travail photographique n’a pas vocation à examiner les peintures murales, les coupoles et les statues sous l’angle de l’histoire de l’art ou celui de la théologie. Il témoigne de la diversité du pittoresque et de la virtuosité des artistes qui durant 200 ans (1580-1780) ont crée ces œuvres; il en illustre le fonctionnement par le biais du regard inventif et perspicace de Christian Ramade qui, ayant franchi les grilles et les claustras, s’est immiscé au milieu des sculptures pour prendre les mises en scène et les personnages dans leur intimité. Personnages peints et sculptés se mêlent ; ces derniers ne sont souvent modelés qu’en partie du coté visible par les spectateur. L’illusion est reine. \r\n(Ces chapelles n’étant pas électrifiées le travail fut souvent réalisé par la technique du “light painting” et certains tirages ont nécessités l’assemblage d’une douzaine d’images afin de pouvoir réaliser des panneaux de plusieurs mètres pour l’exposition de Turin).\r\n                                           \r\n                              Orta  exposition à Marseille au palais Carli en 2010 et à Turin au musée des sciences naturelles en 2011	\N	{}	public	\N	\N	cmt5w6u7t001j22pmzxfj07h9	f
\.


--
-- Data for Name: subscribers; Type: TABLE DATA; Schema: public; Owner: christian
--

COPY public.subscribers (id, email, "createdAt") FROM stdin;
\.


--
-- Data for Name: tickets; Type: TABLE DATA; Schema: public; Owner: christian
--

COPY public.tickets (id, title, slug, content, excerpt, "coverUrl", "coverKey", status, tags, "order", "createdAt", "updatedAt") FROM stdin;
cmt5w6u7t001j22pmzxfj07h9	Les trésors cachés du Sacro monte d’Orta	les-tresors-caches-du-sacro-monte-dorta	<p style="margin-bottom: 24px; text-align: justify; font-style: normal; font-variant-caps: normal; font-width: normal; font-size: 14px; line-height: normal; font-family: Arial; font-size-adjust: none; font-kerning: auto; font-variant-alternates: normal; font-variant-ligatures: normal; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-position: normal; font-variant-emoji: normal; font-feature-settings: normal; font-optical-sizing: auto; font-variation-settings: normal; color: rgb(38, 38, 38);">Le lac d’Orta est situé dans le Piémont en Italie. Au XIX siècle c’était le lac favori des grands romantiques. Au XVI siècle sur les hauteurs boisées du lac furent édifiées vingt chapelles; un chantier pharaonique qui dura 200 ans. Ces chapelles qui constituent un chemin de dévotion sont décorées de peintures murales et habitées par 800 statues en terre cuite polychrome grandeur nature d’un réalisme saisissant. Les chapelles ne sont pas électrifiées et des grilles et claustras en interdisant l’accès le public ne peut admirer ces merveilles qu’à distance depuis le porche d’entrée. Ces sanctuaires illustrent des épisodes de la vie de Saint François d’Assise. Le sacro monte est inscrit depuis 2003 au patrimoine mondial de l’unesco. Il a fallu un an à Christian Ramade pour obtenir les autorisations de pénétrer dans les 21 chapelles et photographier les statues. Ce travail s’est étalé sur une année. Cette exposition fut présentée en 2010 au Palais des arts à Marseille puis en octobre 2011 au Palais des sciences de la ville de Turin.</p>\r\n<p style="margin-bottom: 24px; text-align: justify; font-style: normal; font-variant-caps: normal; font-width: normal; font-size: 14px; line-height: normal; font-family: Arial; font-size-adjust: none; font-kerning: auto; font-variant-alternates: normal; font-variant-ligatures: normal; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-position: normal; font-variant-emoji: normal; font-feature-settings: normal; font-optical-sizing: auto; font-variation-settings: normal; color: rgb(38, 38, 38);">Ce travail photographique n’a pas vocation à examiner les peintures murales, les coupoles et les statues sous l’angle de l’histoire de l’art ou celui de la théologie. Il témoigne de la diversité du pittoresque et de la virtuosité des artistes qui durant 200 ans (1580-1780) ont crée ces œuvres; il en illustre le fonctionnement par le biais du regard inventif et perspicace de Christian Ramade qui, ayant franchi les grilles et les claustras, s’est immiscé au milieu des sculptures pour prendre les mises en scène et les personnages dans leur intimité. Personnages peints et sculptés se mêlent&nbsp;; ces derniers ne sont souvent modelés qu’en partie du coté visible par les spectateur. L’illusion est reine.&nbsp;</p>\r\n<p style="margin-bottom: 24px; text-align: justify; font-style: normal; font-variant-caps: normal; font-width: normal; font-size: 11px; line-height: normal; font-family: Arial; font-size-adjust: none; font-kerning: auto; font-variant-alternates: normal; font-variant-ligatures: normal; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-position: normal; font-variant-emoji: normal; font-feature-settings: normal; font-optical-sizing: auto; font-variation-settings: normal; color: rgb(38, 38, 38);">(<i>Ces chapelles n’étant pas électrifiées le travail fut souvent réalisé par la technique du “light painting” et certains tirages ont nécessités l’assemblage d’une douzaine d’images afin de pouvoir réaliser des panneaux de plusieurs mètres pour l’exposition de Turin</i>).</p><div><br></div>	\N	\N	\N	published	{}	0	2026-08-23 14:18:15.545	2026-08-23 14:20:05.403
\.


--
-- Data for Name: timeline_items; Type: TABLE DATA; Schema: public; Owner: christian
--

COPY public.timeline_items (id, title, year, description, "order", "profileId", "createdAt", "updatedAt", location) FROM stdin;
\.


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: christian
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: books books_pkey; Type: CONSTRAINT; Schema: public; Owner: christian
--

ALTER TABLE ONLY public.books
    ADD CONSTRAINT books_pkey PRIMARY KEY (id);


--
-- Name: featured_works featured_works_pkey; Type: CONSTRAINT; Schema: public; Owner: christian
--

ALTER TABLE ONLY public.featured_works
    ADD CONSTRAINT featured_works_pkey PRIMARY KEY (id);


--
-- Name: homepages homepages_pkey; Type: CONSTRAINT; Schema: public; Owner: christian
--

ALTER TABLE ONLY public.homepages
    ADD CONSTRAINT homepages_pkey PRIMARY KEY (id);


--
-- Name: photos photos_pkey; Type: CONSTRAINT; Schema: public; Owner: christian
--

ALTER TABLE ONLY public.photos
    ADD CONSTRAINT photos_pkey PRIMARY KEY (id);


--
-- Name: profiles profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: christian
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_pkey PRIMARY KEY (id);


--
-- Name: series series_pkey; Type: CONSTRAINT; Schema: public; Owner: christian
--

ALTER TABLE ONLY public.series
    ADD CONSTRAINT series_pkey PRIMARY KEY (id);


--
-- Name: subscribers subscribers_pkey; Type: CONSTRAINT; Schema: public; Owner: christian
--

ALTER TABLE ONLY public.subscribers
    ADD CONSTRAINT subscribers_pkey PRIMARY KEY (id);


--
-- Name: tickets tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: christian
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_pkey PRIMARY KEY (id);


--
-- Name: timeline_items timeline_items_pkey; Type: CONSTRAINT; Schema: public; Owner: christian
--

ALTER TABLE ONLY public.timeline_items
    ADD CONSTRAINT timeline_items_pkey PRIMARY KEY (id);


--
-- Name: series_slug_key; Type: INDEX; Schema: public; Owner: christian
--

CREATE UNIQUE INDEX series_slug_key ON public.series USING btree (slug);


--
-- Name: subscribers_email_key; Type: INDEX; Schema: public; Owner: christian
--

CREATE UNIQUE INDEX subscribers_email_key ON public.subscribers USING btree (email);


--
-- Name: tickets_slug_key; Type: INDEX; Schema: public; Owner: christian
--

CREATE UNIQUE INDEX tickets_slug_key ON public.tickets USING btree (slug);


--
-- Name: books books_profileId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: christian
--

ALTER TABLE ONLY public.books
    ADD CONSTRAINT "books_profileId_fkey" FOREIGN KEY ("profileId") REFERENCES public.profiles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: featured_works featured_works_homepageId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: christian
--

ALTER TABLE ONLY public.featured_works
    ADD CONSTRAINT "featured_works_homepageId_fkey" FOREIGN KEY ("homepageId") REFERENCES public.homepages(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: featured_works featured_works_seriesId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: christian
--

ALTER TABLE ONLY public.featured_works
    ADD CONSTRAINT "featured_works_seriesId_fkey" FOREIGN KEY ("seriesId") REFERENCES public.series(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: photos photos_seriesId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: christian
--

ALTER TABLE ONLY public.photos
    ADD CONSTRAINT "photos_seriesId_fkey" FOREIGN KEY ("seriesId") REFERENCES public.series(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: series series_linkedTicketId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: christian
--

ALTER TABLE ONLY public.series
    ADD CONSTRAINT "series_linkedTicketId_fkey" FOREIGN KEY ("linkedTicketId") REFERENCES public.tickets(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: timeline_items timeline_items_profileId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: christian
--

ALTER TABLE ONLY public.timeline_items
    ADD CONSTRAINT "timeline_items_profileId_fkey" FOREIGN KEY ("profileId") REFERENCES public.profiles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict B8MZZiox2VrCAZy4vgh3tj552mPSWPzXKFHA0bepidroDwPaFAxughEdLZJeEyB

